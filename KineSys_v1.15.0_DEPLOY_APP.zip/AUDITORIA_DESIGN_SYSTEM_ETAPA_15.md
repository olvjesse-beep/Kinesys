# KineSys Clinical v1.11.2 — Design System Final / Etapa 15

**Status:** versão de produção do Design System  
**Data:** 2026-08-29  
**Escopo:** arquitetura visual, cascata, tokens, CSS inline e validação estrutural.  
**Fora de escopo:** regras clínicas, Supabase, permissões, lógica financeira e regras funcionais.

## Resultado executivo

A Etapa 15 encerra a consolidação iniciada na Etapa 1 sem redesenhar o KineSys. A identidade visual aprovada foi preservada e a autoridade visual deixou de depender de blocos `<style>` espalhados no HTML ou de aliases históricos.

### Critérios de produção atingidos

- **0 blocos `<style>` no `KineSys.html`**.
- **0 propriedades visuais estáticas em atributos `style`**; os 31 atributos restantes são exclusivamente `display:none`, usados como estado inicial funcional.
- **0 referências a aliases visuais legados** (`--azul-petroleo`, `--texto-secundario`, `--ks-petrol`, `--ks-line` etc.).
- **0 tokens `--kds-*` indefinidos**.
- **0 conflitos de mesma propriedade entre módulos** no mesmo seletor/contexto responsivo.
- Todos os **12 stylesheets de produção são carregados no `<head>`**, em uma ordem única e documentada.
- **0 IDs duplicados**.
- **0 referências locais ausentes**.
- Os **22 JavaScripts de produção** passam em `node --check`.
- Todos os CSS externos passam no parser CSS.

## Ordem oficial da cascata

1. `design_tokens.css` — tokens e contratos globais.
2. `design_base.css` — base estrutural histórica ainda viva, externalizada do HTML.
3. `design_responsive.css` — regras responsivas transversais.
4. `design_foundation.css` — ritmo, contenção e fundação do shell de conteúdo.
5. `design_features.css` — Home, análise administrativa e configurações.
6. `design_components.css` — cards, botões, campos e componentes compartilhados.
7. `design_screens.css` — telas sem módulo dedicado.
8. `design_typography.css` — escala e papéis tipográficos.
9. `design_navigation.css` — sidebar, topbar e offsets do shell.
10. `design_agenda.css` — Agenda.
11. `design_clinical.css` — Avaliação e Motor Clínico.
12. `design_utilities.css` — utilitários explícitos que substituem antigo CSS visual inline.

**Regra de manutenção:** não criar `<style>` em HTML, não criar novos aliases fora de `--kds-*`, não duplicar uma mesma propriedade para o mesmo seletor/contexto em dois módulos.

## CSS inline externalizado

Os seis blocos CSS que ainda estavam dentro do HTML na Etapa 14 foram externalizados preservando a ordem original da cascata:

- base + fluxos + relatórios → `design_base.css`;
- Home + análise administrativa + configurações → `design_features.css`.

Não houve mudança de posição relativa na cascata: apenas a fonte física saiu do HTML.

## Tokens legados aposentados

Os nomes antigos foram substituídos por tokens semânticos `--kds-*` mantendo **os mesmos valores finais**, inclusive quando não coincidiam com os tokens principais. Exemplos:

- `--azul-petroleo` → `--kds-text`;
- `--texto-secundario` → `--kds-text-subtle`;
- `--ks-petrol` → `--kds-petrol-deep`;
- `--ks-line` → `--kds-line-strong`;
- `--ks-line-soft` → `--kds-line-subtle`.

As variáveis dinâmicas da grade da Agenda também passaram para o namespace KDS:

- `--kds-agenda-runtime-day-count`;
- `--kds-agenda-runtime-slot-count`.

Essa foi a **única alteração em JavaScript** da Etapa 15 e é apenas uma renomeação de propriedade CSS; nenhuma regra funcional da Agenda mudou.

## Concorrência entre módulos

A auditoria encontrou inicialmente 17 casos em que o mesmo seletor/contexto tinha a **mesma propriedade** definida em dois módulos. Esses casos foram resolvidos atribuindo a propriedade à fonte semântica correta.

Exemplos:

- tipografia de notificações → `design_typography.css`;
- `top` do contexto do paciente → `design_navigation.css`;
- tipografia de Safety/links clínicos → `design_typography.css`;
- cor/tamanho da seta dos cards da Home → `design_screens.css`;
- propriedades móveis do prontuário → `design_screens.css`.

Resultado final: **0 conflitos de mesma propriedade entre arquivos para o mesmo seletor/contexto**.

Ainda existem 54 seletores/contextos presentes em mais de um módulo, porém sem propriedade sobreposta. Isso representa divisão intencional de responsabilidade (ex.: layout em um módulo e tipografia em outro), e não guerra de cascata.

## `!important`

Total ativo final: **785**.

A Etapa 15 **não força uma redução artificial** desse número. Os testes das etapas 11–14 já demonstraram que parte significativa ainda compensa especificidade histórica entre seletores diferentes. Removê-los sem uma reescrita funcional/DOM maior causaria regressões reais.

A diferença agora é arquitetural: os `!important` restantes não mascaram CSS inline visual nem aliases legados e não existem conflitos de mesma propriedade entre módulos para o mesmo seletor/contexto. Eles ficam registrados como **dívida de compatibilidade controlada**, não como motivo para reabrir o redesign.

## Design Freeze preservado

- corpo: **16 px**;
- campos: **15,5 px**;
- input/select: **45 px**;
- labels: **13,5 px**;
- sidebar: **14,5 px**;
- título de página: **31 px**;
- Regiões: **17 px**;
- nome da região: **21 px**;
- Eixos: **18 px**;
- Achados: **15 px**;
- Agenda compacta: **14 px / 42 px**.

## Responsividade

Breakpoints máximos oficiais mantidos:

`1280, 1180, 1100, 980, 900, 820, 760, 700, 620, 560, 520, 430 px`

`min-width:701px` permanece como par lógico do corte de 700 px.

## Validação técnica final

- CSS externos: **12/12 parse OK**.
- JS de produção: **22/22 sintaxe OK**.
- IDs duplicados: **0**.
- referências locais ausentes: **0**.
- `<style>` no HTML: **0**.
- inline visual estático: **0**.
- aliases visuais legados: **0**.
- tokens KDS usados: **95**.
- tokens KDS definidos/runtime: **95**.
- tokens KDS indefinidos: **0**.
- conflitos intermodulares de mesma propriedade: **0**.

## Limitação de validação visual

O ambiente de desenvolvimento não permite finalizar uma sessão Chromium headless confiável. Portanto, esta auditoria **não afirma inspeção pixel-a-pixel em navegador real**. A validação é estrutural, de cascata, tokens, sintaxe e preservação dos contratos definidos nas etapas anteriores.

## Parecer final

**APROVADO PARA PRODUÇÃO DO DESIGN SYSTEM, com dívida de compatibilidade documentada nos `!important` remanescentes.**

Novas alterações visuais devem partir deste contrato. Não reintroduzir patches no HTML ou novos sistemas paralelos de tokens/componentes.
