﻿$ErrorActionPreference='Stop'
$src=Split-Path -Parent $MyInvocation.MyCommand.Path
$dest=Join-Path $env:LOCALAPPDATA 'KineSysLocal'
# Encerra uma versão antiga do serviço antes de atualizar o script, evitando manter a porta 8765 presa.
try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessId -ne $PID -and $_.Name -match 'powershell' -and $_.CommandLine -match 'KineSysLocal\.ps1'
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Milliseconds 500
} catch {}
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Force (Join-Path $src 'KineSysLocal.ps1') (Join-Path $dest 'KineSysLocal.ps1')
if (Test-Path (Join-Path $src 'kinesys_local_config.json')) {
    if (!(Test-Path (Join-Path $dest 'kinesys_local_config.json'))) { Copy-Item (Join-Path $src 'kinesys_local_config.json') (Join-Path $dest 'kinesys_local_config.json') }
}
$user=[Security.Principal.WindowsIdentity]::GetCurrent().Name
cmd /c "netsh http delete urlacl url=http://+:8765/" | Out-Null
cmd /c "netsh http add urlacl url=http://+:8765/ user=\"$user\"" | Out-Null
try { Remove-NetFirewallRule -DisplayName 'KineSys Local 8765' -ErrorAction SilentlyContinue } catch {}
New-NetFirewallRule -DisplayName 'KineSys Local 8765' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8765 -RemoteAddress LocalSubnet | Out-Null
$startup=[Environment]::GetFolderPath('Startup')
$desktop=[Environment]::GetFolderPath('Desktop')
$wsh=New-Object -ComObject WScript.Shell
foreach($pair in @(@((Join-Path $startup 'KineSys Local.lnk'),'Minimizado'),@((Join-Path $desktop 'KineSys Local - Iniciar.lnk'),'Normal'))){
    $lnk=$wsh.CreateShortcut($pair[0]);$lnk.TargetPath='powershell.exe';$lnk.Arguments="-NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File `"$(Join-Path $dest 'KineSysLocal.ps1')`"";$lnk.WorkingDirectory=$dest;$lnk.Save()
}
Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $dest 'KineSysLocal.ps1')`""
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("KineSys Local instalado.\n\nO serviço iniciará automaticamente com o Windows.\nNo KineSys, abra Fotos e Documentos para ver o endereço do iPhone e o código de pareamento.",'KineSys Local') | Out-Null
