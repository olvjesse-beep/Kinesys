KineSys Local v1.10.2 — iPhone + importação de documentos do Windows

PRIMEIRA INSTALAÇÃO
1. No Windows, execute INSTALAR_KINESYS_LOCAL_ADMIN.bat.
2. Aceite a janela de Administrador. O instalador libera somente a porta 8765 para a rede local e configura inicialização automática.
3. Abra o KineSys > Fotos e documentos.
4. O painel mostrará um endereço como http://192.168.1.25:8765/camera e um código de 6 dígitos.
5. No iPhone, estando na mesma rede Wi-Fi, abra esse endereço no Safari.
6. Digite o código uma única vez e use Compartilhar > Adicionar à Tela de Início. Nome sugerido: KineSys Câmera.

ATUALIZAÇÃO DE UMA INSTALAÇÃO ANTERIOR
Se o KineSys Local já estava instalado, execute novamente INSTALAR_KINESYS_LOCAL_ADMIN.bat uma vez. O instalador atualiza o script em %LOCALAPPDATA%\KineSysLocal e preserva a configuração existente.


IMPORTAR DOCUMENTOS DO COMPUTADOR / SCANNER
1. Digitalize o documento pela impressora/multifuncional usando o software do fabricante ou o aplicativo Scanner do Windows.
2. Salve o resultado no computador, preferencialmente em PDF, JPG ou PNG.
3. No KineSys > Fotos e documentos, selecione o paciente e o tipo do documento.
4. Clique em Importar do computador e escolha um ou vários arquivos.
5. O original será copiado para a pasta Documentos do paciente; o Supabase receberá somente os metadados.
6. Formatos aceitos: PDF, JPG/JPEG, PNG, WEBP, TIFF, BMP, DOC/DOCX, XLS/XLSX, TXT e RTF. Limite: 50 MB por arquivo e até 20 arquivos por importação.

USO DIÁRIO
1. Abra o prontuário/Fotos e documentos no Windows.
2. Selecione o paciente e clique em Capturar com iPhone.
3. Abra KineSys Câmera no iPhone. O nome do paciente aparece para conferência.
4. Escolha tipo/região, toque em Tirar foto e confirme a foto na câmera do iPhone.
5. O envio é automático. A imagem aparece na galeria do paciente no Windows.

ARMAZENAMENTO
Fotografias clínicas: C:\KineSys\Dados\Pacientes\<paciente_id>\Fotos\AAAA\MM
Documentos administrativos: C:\KineSys\Dados\Pacientes\<paciente_id>\Documentos\AAAA\MM
Miniaturas locais: C:\KineSys\Dados\Pacientes\<paciente_id>\Miniaturas\AAAA\MM
Nenhum original de foto/documento é enviado ao Supabase por este fluxo; o banco recebe somente metadados de vínculo.

BACKUP
No KineSys > Fotos e documentos > Armazenamento e backup local, informe por exemplo E:\KineSys_Backup ou uma pasta em NAS acessível pelo Windows. Cada foto nova é copiada automaticamente quando o destino está disponível.

SEGURANÇA
- O iPhone precisa ser pareado uma vez com código de 6 dígitos.
- O serviço aceita sessão de paciente, galeria e configurações somente pelo próprio Windows (loopback).
- A porta do firewall é limitada à rede local.
- A confirmação do nome do paciente aparece no iPhone antes da captura.
- Recomenda-se Windows com BitLocker e pasta de backup protegida.
