﻿# KineSys Local v1.10.2 — importação de documentos do Windows + exclusão segura de paciente
# Serviço local para captura de fotos clínicas pelo iPhone via Wi-Fi.
# Originais permanecem no Windows; somente metadados são sincronizados pelo KineSys web.

$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $ScriptDir 'kinesys_local_config.json'
$DefaultDataRoot = 'C:\KineSys\Dados'

function New-RandomToken {
    return ([guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N'))
}

function Load-Config {
    $cfg = $null
    if (Test-Path $ConfigPath) {
        try { $cfg = Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
    }
    if (!$cfg) {
        $cfg = [pscustomobject]@{ port = 8765; data_root = $DefaultDataRoot; backup_root = ''; pair_token = (New-RandomToken) }
    }
    if (!$cfg.port) { $cfg.port = 8765 }
    if ([string]::IsNullOrWhiteSpace([string]$cfg.data_root)) { $cfg.data_root = $DefaultDataRoot }
    if ($null -eq $cfg.backup_root) { $cfg.backup_root = '' }
    if ([string]::IsNullOrWhiteSpace([string]$cfg.pair_token)) { $cfg.pair_token = New-RandomToken }
    Save-Config $cfg
    return $cfg
}

function Save-Config($cfg) {
    $json = $cfg | ConvertTo-Json -Depth 6
    [IO.File]::WriteAllText($ConfigPath, $json, (New-Object Text.UTF8Encoding($false)))
}

$Config = Load-Config
$Port = [int]$Config.port
$DataRoot = [string]$Config.data_root
$BackupRoot = [string]$Config.backup_root
$PairToken = [string]$Config.pair_token
$PairCode = (Get-Random -Minimum 100000 -Maximum 999999).ToString()
$StationName = $env:COMPUTERNAME
$IndexPath = Join-Path $DataRoot 'midias_index.jsonl'
$script:ActiveSession = $null

New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null

function Is-LoopbackRequest($ctx) {
    try { return [Net.IPAddress]::IsLoopback($ctx.Request.RemoteEndPoint.Address) } catch { return $false }
}

function Add-Cors($resp) {
    $resp.Headers['Access-Control-Allow-Origin'] = '*'
    $resp.Headers['Access-Control-Allow-Methods'] = 'GET,POST,OPTIONS'
    $resp.Headers['Access-Control-Allow-Headers'] = 'Content-Type'
    $resp.Headers['Cache-Control'] = 'no-store'
}

function Send-Json($ctx, $obj, [int]$status = 200) {
    $json = $obj | ConvertTo-Json -Depth 10 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.StatusCode = $status
    $ctx.Response.ContentType = 'application/json; charset=utf-8'
    Add-Cors $ctx.Response
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Send-Html($ctx, [string]$html, [int]$status = 200) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($html)
    $ctx.Response.StatusCode = $status
    $ctx.Response.ContentType = 'text/html; charset=utf-8'
    $ctx.Response.Headers['Cache-Control'] = 'no-store'
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Send-Text($ctx, [string]$text, [int]$status = 200) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($text)
    $ctx.Response.StatusCode = $status
    $ctx.Response.ContentType = 'text/plain; charset=utf-8'
    Add-Cors $ctx.Response
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Read-JsonBody($ctx) {
    $reader = New-Object IO.StreamReader($ctx.Request.InputStream, $ctx.Request.ContentEncoding)
    try { $txt = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ([string]::IsNullOrWhiteSpace($txt)) { return [pscustomobject]@{} }
    return $txt | ConvertFrom-Json
}

function Get-CookieValue($ctx, [string]$name) {
    try {
        $cookie = $ctx.Request.Cookies[$name]
        if ($cookie) { return [string]$cookie.Value }
    } catch {}
    return ''
}

function Is-Paired($ctx) {
    return (Get-CookieValue $ctx 'kinesys_pair') -eq $PairToken
}

function Sanitize-Part([string]$value, [string]$fallback='registro') {
    if ([string]::IsNullOrWhiteSpace($value)) { return $fallback }
    $v = $value.ToLowerInvariant().Normalize([Text.NormalizationForm]::FormD)
    $sb = New-Object Text.StringBuilder
    foreach ($c in $v.ToCharArray()) {
        $cat = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($c)
        if ($cat -eq [Globalization.UnicodeCategory]::NonSpacingMark) { continue }
        if ([char]::IsLetterOrDigit($c)) { [void]$sb.Append($c) }
        elseif ($c -eq ' ' -or $c -eq '_' -or $c -eq '-') { [void]$sb.Append('-') }
    }
    $out = $sb.ToString() -replace '-+','-'
    $out = $out.Trim('-')
    if (!$out) { return $fallback }
    if ($out.Length -gt 48) { $out = $out.Substring(0,48) }
    return $out
}

function Get-PrivateIPv4 {
    $all = @()
    try {
        $all = [Net.Dns]::GetHostAddresses($env:COMPUTERNAME) | Where-Object {
            $_.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork -and -not [Net.IPAddress]::IsLoopback($_)
        } | ForEach-Object { $_.IPAddressToString }
    } catch {}
    $private = $all | Where-Object { $_ -match '^10\.' -or $_ -match '^192\.168\.' -or $_ -match '^172\.(1[6-9]|2\d|3[01])\.' }
    if ($private) { return @($private) }
    return @($all)
}

function Read-Index {
    if (!(Test-Path $IndexPath)) { return @() }
    $items = @()
    foreach ($line in [IO.File]::ReadAllLines($IndexPath, [Text.Encoding]::UTF8)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try { $items += ($line | ConvertFrom-Json) } catch {}
    }
    return @($items)
}

function Write-Index($items) {
    $enc = New-Object Text.UTF8Encoding($false)
    $sw = New-Object IO.StreamWriter($IndexPath, $false, $enc)
    try { foreach($i in $items){ $sw.WriteLine(($i | ConvertTo-Json -Depth 8 -Compress)) } } finally { $sw.Dispose() }
}

function Append-Index($item) {
    $enc = New-Object Text.UTF8Encoding($false)
    $sw = New-Object IO.StreamWriter($IndexPath, $true, $enc)
    try { $sw.WriteLine(($item | ConvertTo-Json -Depth 8 -Compress)) } finally { $sw.Dispose() }
}

function Get-MediaById([string]$id) {
    return (Read-Index | Where-Object { $_.id -eq $id } | Select-Object -First 1)
}

function New-Thumbnail([string]$source, [string]$dest) {
    try {
        Add-Type -AssemblyName System.Drawing
        $img = [Drawing.Image]::FromFile($source)
        try {
            $maxW = 520; $maxH = 390
            $ratio = [Math]::Min($maxW / $img.Width, $maxH / $img.Height)
            if ($ratio -gt 1) { $ratio = 1 }
            $w = [Math]::Max(1,[int]($img.Width*$ratio)); $h = [Math]::Max(1,[int]($img.Height*$ratio))
            $bmp = New-Object Drawing.Bitmap($w,$h)
            try {
                $g = [Drawing.Graphics]::FromImage($bmp)
                try {
                    $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $g.DrawImage($img,0,0,$w,$h)
                } finally { $g.Dispose() }
                $codec = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object {$_.MimeType -eq 'image/jpeg'} | Select-Object -First 1
                $ep = New-Object Drawing.Imaging.EncoderParameters(1)
                $ep.Param[0] = New-Object Drawing.Imaging.EncoderParameter([Drawing.Imaging.Encoder]::Quality, [long]72)
                $bmp.Save($dest,$codec,$ep)
                $ep.Dispose()
            } finally { $bmp.Dispose() }
        } finally { $img.Dispose() }
        return $true
    } catch { return $false }
}

function Copy-ToBackup($meta) {
    if ([string]::IsNullOrWhiteSpace($BackupRoot)) { return 'pending' }
    try {
        if (!(Test-Path $BackupRoot)) { New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null }
        $src = Join-Path $DataRoot $meta.relative_path
        $dst = Join-Path $BackupRoot $meta.relative_path
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        Copy-Item -Force $src $dst
        if ($meta.thumbnail_relative_path) {
            $ts = Join-Path $DataRoot $meta.thumbnail_relative_path
            if (Test-Path $ts) {
                $td = Join-Path $BackupRoot $meta.thumbnail_relative_path
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $td) | Out-Null
                Copy-Item -Force $ts $td
            }
        }
        return 'ok'
    } catch { return 'failed' }
}

function Send-File($ctx, [string]$path, [string]$contentType='image/jpeg') {
    if (!(Test-Path $path)) { Send-Text $ctx 'Arquivo não encontrado.' 404; return }
    $bytes = [IO.File]::ReadAllBytes($path)
    $ctx.Response.StatusCode = 200
    $ctx.Response.ContentType = $contentType
    $ctx.Response.Headers['Cache-Control'] = 'private, max-age=300'
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Pair-Page {
return @'
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>KineSys Câmera</title>
<style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f3f7f6;color:#173b45;margin:0;padding:28px}.card{max-width:520px;margin:8vh auto;background:#fff;border-radius:18px;padding:24px;box-shadow:0 18px 50px rgba(23,59,69,.12)}h1{font-size:26px;margin:0 0 5px}.sub{color:#718086;font-size:14px;margin-bottom:22px}.code{font-size:28px;letter-spacing:9px;width:100%;box-sizing:border-box;text-align:center;padding:13px;border:1px solid #cad9d5;border-radius:12px}button{margin-top:12px;width:100%;border:0;border-radius:12px;padding:14px;background:#2aa79d;color:#fff;font-size:16px;font-weight:800}.msg{font-size:13px;color:#b42318;margin-top:10px}</style></head><body><div class="card"><h1>KineSys Câmera</h1><div class="sub">Pareamento inicial com este computador. Digite o código de 6 dígitos exibido no KineSys do Windows.</div><input class="code" id="code" inputmode="numeric" maxlength="6" placeholder="000000"><button onclick="pair()">Parear iPhone</button><div class="msg" id="msg"></div></div>
<script>async function pair(){const code=document.getElementById('code').value.replace(/\D/g,'');const r=await fetch('/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code})});const d=await r.json().catch(()=>({}));if(r.ok){location.reload()}else document.getElementById('msg').textContent=d.error||'Código inválido.'}</script></body></html>
'@
}

function Camera-Page {
return @'
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><title>KineSys Câmera</title>
<style>:root{--pet:#173b45;--green:#2aa79d;--muted:#718086}*{box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;background:#f2f7f5;color:var(--pet);padding:env(safe-area-inset-top) 16px env(safe-area-inset-bottom)}.wrap{max-width:620px;margin:0 auto;padding:18px 0}.brand{font-weight:900;letter-spacing:.5px;font-size:18px}.brand span{color:var(--green)}.card{background:#fff;border-radius:18px;padding:18px;margin-top:14px;box-shadow:0 12px 34px rgba(23,59,69,.09)}.ey{font-size:10px;font-weight:900;letter-spacing:1px;color:var(--green)}h1{font-size:24px;margin:4px 0}.muted{color:var(--muted);font-size:13px;line-height:1.45}.patient{padding:13px 14px;background:#f2f8f6;border:1px solid #d5e6e1;border-radius:13px;margin:12px 0;font-size:15px;font-weight:800}.grid{display:grid;gap:10px}label{font-size:11px;font-weight:800;color:var(--muted)}select,input[type=text],textarea{width:100%;border:1px solid #cbdad6;border-radius:11px;padding:12px;font-size:16px;background:#fff}.capture{display:block;margin-top:14px;background:var(--green);color:#fff;border-radius:14px;padding:16px;text-align:center;font-size:17px;font-weight:900}.capture input{display:none}.status{margin-top:10px;min-height:22px;font-size:13px;color:var(--muted)}.ok{color:#237a4a;font-weight:800}.err{color:#b42318;font-weight:800}.preview{display:none;margin-top:12px;border-radius:14px;overflow:hidden;background:#eef3f1}.preview img{display:block;width:100%;max-height:420px;object-fit:contain}.spinner{display:inline-block;width:15px;height:15px;border:2px solid #ccd8d5;border-top-color:var(--green);border-radius:50%;animation:s .7s linear infinite;vertical-align:-3px;margin-right:7px}@keyframes s{to{transform:rotate(360deg)}}button.secondary{width:100%;border:1px solid #cbdad6;background:#fff;color:var(--pet);border-radius:12px;padding:12px;font-weight:800;margin-top:10px}</style></head><body><div class="wrap"><div class="brand">KINE<span>SYS</span> Câmera</div><div class="card"><div class="ey">CAPTURA CLÍNICA LOCAL</div><h1 id="title">Aguardando paciente…</h1><div class="muted" id="sub">No computador, abra o prontuário e clique em “Capturar com iPhone”.</div><div class="patient" id="patient" style="display:none"></div><div class="grid"><div><label>Tipo do registro</label><select id="type"><option value="">Aguardando permissão do computador…</option></select></div><div><label>Região / identificação</label><input type="text" id="region" placeholder="Ex.: Ombro direito"></div><div><label>Observação opcional</label><textarea id="desc" rows="2" placeholder="Ex.: foto inicial antes da sessão"></textarea></div></div><label class="capture" id="captureLabel">📷 Tirar foto<input id="file" type="file" accept="image/*" capture="environment" disabled></label><div class="preview" id="preview"><img id="previewImg"></div><div class="status" id="status"></div><button class="secondary" onclick="refreshSession()">↻ Atualizar paciente</button></div></div>
<script>
let session=null;let lastPatient='';const file=document.getElementById('file');const typeSelect=document.getElementById('type');
const TYPE_LABELS={evolucao:'Evolução',avaliacao:'Avaliação',postura:'Postura',ferida:'Ferida / cicatriz',edema:'Edema',exame:'Exame / laudo',termo:'Termo / autorização',identificacao:'Identificação / CPF / RG',guia:'Guia / pedido',documento:'Documento',outro_admin:'Outro documento',outro:'Outro registro clínico'};
function applyAllowedTypes(){const allowed=Array.isArray(session?.allowed_types)&&session.allowed_types.length?session.allowed_types:Object.keys(TYPE_LABELS);const atual=typeSelect.value;typeSelect.innerHTML=allowed.filter(x=>TYPE_LABELS[x]).map(x=>'<option value="'+x+'">'+TYPE_LABELS[x]+'</option>').join('');if(atual&&allowed.includes(atual))typeSelect.value=atual;document.querySelector('.ey').textContent=session?.started_role==='SECRETARIA'?'CAPTURA DOCUMENTAL LOCAL':'CAPTURA CLÍNICA LOCAL';}
async function refreshSession(){try{const r=await fetch('/api/session',{cache:'no-store'});if(!r.ok)throw 0;const d=await r.json();session=d.session||null;if(session&&session.patient_id){applyAllowedTypes();document.getElementById('title').textContent=session.started_role==='SECRETARIA'?'Pronto para digitalizar':'Pronto para fotografar';document.getElementById('patient').style.display='block';document.getElementById('patient').textContent=session.patient_name;document.getElementById('sub').textContent='Confirme o paciente acima antes de registrar a imagem.';file.disabled=false;if(lastPatient!==session.patient_id){lastPatient=session.patient_id;document.getElementById('status').textContent='';document.getElementById('preview').style.display='none';}}else{document.getElementById('title').textContent='Aguardando paciente…';document.getElementById('patient').style.display='none';document.getElementById('sub').textContent='No computador, abra o prontuário e clique em “Capturar com iPhone”.';typeSelect.innerHTML='<option value="">Aguardando paciente…</option>';file.disabled=true;}}catch(e){document.getElementById('status').className='status err';document.getElementById('status').textContent='Não foi possível comunicar com o computador.'}}
async function normalizeJpeg(f){const img=document.createElement('img');const url=URL.createObjectURL(f);await new Promise((res,rej)=>{img.onload=res;img.onerror=rej;img.src=url});const max=2400;let w=img.naturalWidth,h=img.naturalHeight;const sc=Math.min(1,max/Math.max(w,h));w=Math.round(w*sc);h=Math.round(h*sc);const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h);URL.revokeObjectURL(url);return await new Promise(res=>c.toBlob(res,'image/jpeg',.88))}
file.addEventListener('change',async()=>{if(!file.files[0]||!session)return;const st=document.getElementById('status');st.className='status';st.innerHTML='<span class="spinner"></span>Preparando e enviando…';try{const blob=await normalizeJpeg(file.files[0]);const u=URL.createObjectURL(blob);document.getElementById('previewImg').src=u;document.getElementById('preview').style.display='block';const qs=new URLSearchParams({type:document.getElementById('type').value,region:document.getElementById('region').value,description:document.getElementById('desc').value});const r=await fetch('/api/upload?'+qs.toString(),{method:'POST',headers:{'Content-Type':'image/jpeg'},body:blob});const d=await r.json();if(!r.ok)throw new Error(d.error||'Falha no envio');st.className='status ok';st.textContent='✓ Foto recebida no computador e vinculada a '+session.patient_name+'.';file.value='';setTimeout(()=>{document.getElementById('preview').style.display='none';URL.revokeObjectURL(u)},2500)}catch(e){st.className='status err';st.textContent='Falha: '+e.message}});
refreshSession();setInterval(refreshSession,2500);
</script></body></html>
'@
}

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("http://+:$Port/")
try { $listener.Start() } catch {
    Write-Host ''
    Write-Host 'ERRO: não foi possível iniciar o KineSys Local.' -ForegroundColor Red
    Write-Host 'Execute INSTALAR_KINESYS_LOCAL_ADMIN.bat uma vez como administrador.' -ForegroundColor Yellow
    Write-Host $_.Exception.Message
    Read-Host 'Pressione ENTER para fechar'
    exit 1
}

$ips = Get-PrivateIPv4
$iphoneUrl = if($ips.Count -gt 0){ "http://$($ips[0]):$Port/camera" } else { "http://IP-DESTE-PC:$Port/camera" }
Write-Host 'KineSys Local v1.10.2 em execução' -ForegroundColor Green
Write-Host "Originais: $DataRoot"
Write-Host "iPhone:    $iphoneUrl"
Write-Host "Pareamento desta inicialização: $PairCode" -ForegroundColor Cyan
Write-Host 'Mantenha esta janela aberta enquanto usar a captura pelo iPhone.'

while ($listener.IsListening) {
    try {
        $ctx = $listener.GetContext()
        $path = $ctx.Request.Url.AbsolutePath
        $method = $ctx.Request.HttpMethod.ToUpperInvariant()

        if ($method -eq 'OPTIONS') { $ctx.Response.StatusCode=204; Add-Cors $ctx.Response; $ctx.Response.Close(); continue }

        if ($path -eq '/camera' -or $path -eq '/') {
            if (Is-Paired $ctx) { Send-Html $ctx (Camera-Page) } else { Send-Html $ctx (Pair-Page) }
            continue
        }

        if ($path -eq '/pair' -and $method -eq 'POST') {
            try { $body = Read-JsonBody $ctx } catch { Send-Json $ctx @{error='Requisição inválida.'} 400; continue }
            if ([string]$body.code -ne $PairCode) { Send-Json $ctx @{error='Código de pareamento inválido.'} 403; continue }
            $cookie = New-Object Net.Cookie('kinesys_pair',$PairToken,'/')
            $cookie.HttpOnly = $true
            $cookie.Expires = (Get-Date).AddYears(2)
            $ctx.Response.Cookies.Add($cookie)
            Send-Json $ctx @{ok=$true}
            continue
        }

        if ($path -eq '/api/local-status' -and $method -eq 'GET') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='Acesso local necessário.'} 403; continue }
            $ips = Get-PrivateIPv4
            $iphoneUrl = if($ips.Count -gt 0){ "http://$($ips[0]):$Port/camera" } else { '' }
            Send-Json $ctx @{ok=$true;version='1.10.2';port=$Port;iphone_url=$iphoneUrl;ip_addresses=$ips;pair_code=$PairCode;data_root=$DataRoot;backup_root=$BackupRoot;station=$StationName;session=$script:ActiveSession}
            continue
        }

        if ($path -eq '/api/status' -and $method -eq 'GET') {
            Send-Json $ctx @{ok=$true;version='1.10.2';station=$StationName;session=$script:ActiveSession}
            continue
        }

        if ($path -eq '/api/session' -and $method -eq 'POST') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='A sessão clínica só pode ser iniciada no computador.'} 403; continue }
            $body = Read-JsonBody $ctx
            if ([string]::IsNullOrWhiteSpace([string]$body.patient_id)) { Send-Json $ctx @{error='patient_id é obrigatório.'} 400; continue }
            $script:ActiveSession = [pscustomobject]@{
                patient_id = [string]$body.patient_id
                patient_name = [string]$body.patient_name
                started_by = [string]$body.started_by
                started_role = [string]$body.started_role
                allowed_types = @($body.allowed_types)
                started_at = (Get-Date).ToUniversalTime().ToString('o')
            }
            Send-Json $ctx @{ok=$true;session=$script:ActiveSession}
            continue
        }

        if ($path -eq '/api/session' -and $method -eq 'GET') {
            if (!(Is-Paired $ctx)) { Send-Json $ctx @{error='iPhone não pareado.'} 401; continue }
            Send-Json $ctx @{ok=$true;session=$script:ActiveSession}
            continue
        }

        if ($path -eq '/api/upload' -and $method -eq 'POST') {
            if (!(Is-Paired $ctx)) { Send-Json $ctx @{error='iPhone não pareado.'} 401; continue }
            if (!$script:ActiveSession -or [string]::IsNullOrWhiteSpace($script:ActiveSession.patient_id)) { Send-Json $ctx @{error='Nenhum paciente está aguardando captura no computador.'} 409; continue }
            if ($ctx.Request.ContentLength64 -le 0 -or $ctx.Request.ContentLength64 -gt 15728640) { Send-Json $ctx @{error='Imagem vazia ou maior que 15 MB.'} 413; continue }

            $type = Sanitize-Part ([string]$ctx.Request.QueryString['type']) 'outro'
            $allowedTypes = @($script:ActiveSession.allowed_types)
            if ($allowedTypes.Count -gt 0 -and $allowedTypes -notcontains $type) { Send-Json $ctx @{error='Tipo de registro não permitido para este perfil.'} 403; continue }
            $regionText = [string]$ctx.Request.QueryString['region']
            $region = Sanitize-Part $regionText 'sem-regiao'
            $description = [string]$ctx.Request.QueryString['description']
            $patientId = Sanitize-Part ([string]$script:ActiveSession.patient_id) 'paciente'
            $now = Get-Date
            $yyyy = $now.ToString('yyyy'); $mm = $now.ToString('MM')
            $documentTypes = @('termo','identificacao','guia','exame','documento','outro_admin')
            $categoriaPasta = if ($documentTypes -contains $type) { 'Documentos' } else { 'Fotos' }
            $folder = Join-Path $DataRoot ("Pacientes\$patientId\$categoriaPasta\$yyyy\$mm")
            $thumbFolder = Join-Path $DataRoot ("Pacientes\$patientId\Miniaturas\$yyyy\$mm")
            New-Item -ItemType Directory -Force -Path $folder,$thumbFolder | Out-Null
            $suffix = [guid]::NewGuid().ToString('N').Substring(0,6)
            $fileName = "{0}_{1}_{2}_{3}.jpg" -f $now.ToString('yyyy-MM-dd_HHmmss'),$type,$region,$suffix
            $fullPath = Join-Path $folder $fileName
            $fs = New-Object IO.FileStream($fullPath,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try { $ctx.Request.InputStream.CopyTo($fs) } finally { $fs.Dispose() }
            $thumbName = ([IO.Path]::GetFileNameWithoutExtension($fileName) + '_thumb.jpg')
            $thumbPath = Join-Path $thumbFolder $thumbName
            $thumbOk = New-Thumbnail $fullPath $thumbPath
            $relative = $fullPath.Substring($DataRoot.Length).TrimStart('\')
            $thumbRelative = if($thumbOk){$thumbPath.Substring($DataRoot.Length).TrimStart('\')}else{''}
            $hash = (Get-FileHash -Algorithm SHA256 -Path $fullPath).Hash.ToLowerInvariant()
            $id = 'mid_' + $now.ToString('yyyyMMddHHmmssfff') + '_' + $suffix
            $meta = [pscustomobject]@{
                id=$id
                patient_id=[string]$script:ActiveSession.patient_id
                patient_name=[string]$script:ActiveSession.patient_name
                captured_at=$now.ToUniversalTime().ToString('o')
                type=$type
                region=$regionText
                description=$description
                filename=$fileName
                relative_path=$relative
                thumbnail_relative_path=$thumbRelative
                size_bytes=(Get-Item $fullPath).Length
                mime_type='image/jpeg'
                sha256=$hash
                backup_status='pending'
                professional_name=[string]$script:ActiveSession.started_by
                professional_id=''
                station=$StationName
                source_device='iphone'
            }
            $meta.backup_status = Copy-ToBackup $meta
            Append-Index $meta
            Send-Json $ctx @{ok=$true;item=$meta}
            continue
        }

        if ($path -eq '/api/import-document' -and $method -eq 'POST') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='A importação de documentos só pode ser feita neste computador.'} 403; continue }
            if ($ctx.Request.ContentLength64 -le 0 -or $ctx.Request.ContentLength64 -gt 52428800) { Send-Json $ctx @{error='Arquivo vazio ou maior que 50 MB.'} 413; continue }

            $rawPatientId = [string]$ctx.Request.QueryString['patient_id']
            $patientName = [string]$ctx.Request.QueryString['patient_name']
            $type = Sanitize-Part ([string]$ctx.Request.QueryString['type']) 'documento'
            $allowedDocumentTypes = @('termo','identificacao','guia','exame','documento','outro_admin')
            if ([string]::IsNullOrWhiteSpace($rawPatientId)) { Send-Json $ctx @{error='patient_id é obrigatório.'} 400; continue }
            if ($allowedDocumentTypes -notcontains $type) { Send-Json $ctx @{error='Tipo de documento não permitido para importação pelo computador.'} 403; continue }

            $originalName = [IO.Path]::GetFileName([string]$ctx.Request.QueryString['original_name'])
            if ([string]::IsNullOrWhiteSpace($originalName)) { $originalName = 'documento' }
            $ext = [IO.Path]::GetExtension($originalName).ToLowerInvariant()
            $allowedExt = @('.pdf','.jpg','.jpeg','.png','.webp','.tif','.tiff','.bmp','.doc','.docx','.xls','.xlsx','.txt','.rtf')
            if ($allowedExt -notcontains $ext) { Send-Json $ctx @{error='Formato de arquivo não suportado.'} 415; continue }

            $mimeMap = @{
                '.pdf'='application/pdf'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.png'='image/png'; '.webp'='image/webp';
                '.tif'='image/tiff'; '.tiff'='image/tiff'; '.bmp'='image/bmp'; '.doc'='application/msword';
                '.docx'='application/vnd.openxmlformats-officedocument.wordprocessingml.document'; '.xls'='application/vnd.ms-excel';
                '.xlsx'='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'; '.txt'='text/plain'; '.rtf'='application/rtf'
            }
            $mimeType = [string]$ctx.Request.QueryString['mime_type']
            if ([string]::IsNullOrWhiteSpace($mimeType) -or $mimeType -eq 'application/octet-stream') { $mimeType = [string]$mimeMap[$ext] }
            if ([string]::IsNullOrWhiteSpace($mimeType)) { $mimeType = 'application/octet-stream' }

            $patientId = Sanitize-Part $rawPatientId 'paciente'
            $safeBase = Sanitize-Part ([IO.Path]::GetFileNameWithoutExtension($originalName)) 'arquivo'
            $now = Get-Date
            $yyyy = $now.ToString('yyyy'); $mm = $now.ToString('MM')
            $folder = Join-Path $DataRoot ("Pacientes\$patientId\Documentos\$yyyy\$mm")
            $thumbFolder = Join-Path $DataRoot ("Pacientes\$patientId\Miniaturas\$yyyy\$mm")
            New-Item -ItemType Directory -Force -Path $folder,$thumbFolder | Out-Null
            $suffix = [guid]::NewGuid().ToString('N').Substring(0,6)
            $fileName = "{0}_{1}_{2}_{3}{4}" -f $now.ToString('yyyy-MM-dd_HHmmss'),$type,$safeBase,$suffix,$ext
            $fullPath = Join-Path $folder $fileName
            $fs = New-Object IO.FileStream($fullPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try { $ctx.Request.InputStream.CopyTo($fs) } finally { $fs.Dispose() }

            $thumbRelative = ''
            if ($mimeType -like 'image/*') {
                $thumbName = ([IO.Path]::GetFileNameWithoutExtension($fileName) + '_thumb.jpg')
                $thumbPath = Join-Path $thumbFolder $thumbName
                if (New-Thumbnail $fullPath $thumbPath) { $thumbRelative = $thumbPath.Substring($DataRoot.Length).TrimStart('\') }
            }
            $relative = $fullPath.Substring($DataRoot.Length).TrimStart('\')
            $hash = (Get-FileHash -Algorithm SHA256 -Path $fullPath).Hash.ToLowerInvariant()
            $id = 'mid_' + $now.ToString('yyyyMMddHHmmssfff') + '_' + $suffix
            $meta = [pscustomobject]@{
                id=$id
                patient_id=$rawPatientId
                patient_name=$patientName
                captured_at=$now.ToUniversalTime().ToString('o')
                type=$type
                region=''
                description=('Importado do computador · original: ' + $originalName)
                filename=$fileName
                original_filename=$originalName
                relative_path=$relative
                thumbnail_relative_path=$thumbRelative
                size_bytes=(Get-Item $fullPath).Length
                mime_type=$mimeType
                sha256=$hash
                backup_status='pending'
                professional_name=[string]$ctx.Request.QueryString['imported_by']
                professional_id=''
                station=$StationName
                source_device='windows-import'
            }
            $meta.backup_status = Copy-ToBackup $meta
            Append-Index $meta
            Send-Json $ctx @{ok=$true;item=$meta}
            continue
        }

        if ($path -eq '/api/uploads' -and $method -eq 'GET') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='Acesso local necessário.'} 403; continue }
            $patientId = [string]$ctx.Request.QueryString['patient_id']
            $items = Read-Index
            if (![string]::IsNullOrWhiteSpace($patientId)) { $items = @($items | Where-Object { $_.patient_id -eq $patientId }) }
            $items = @($items | Sort-Object captured_at -Descending)
            Send-Json $ctx @{ok=$true;items=$items}
            continue
        }

        if ($path -eq '/api/patient-delete' -and $method -eq 'POST') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='A exclusão de prontuário só pode ser executada no computador.'} 403; continue }
            try { $body = Read-JsonBody $ctx } catch { Send-Json $ctx @{error='Requisição inválida.'} 400; continue }
            $rawPatientId = [string]$body.patient_id
            if ([string]::IsNullOrWhiteSpace($rawPatientId)) { Send-Json $ctx @{error='patient_id é obrigatório.'} 400; continue }
            if ($body.confirm_delete -ne $true) { Send-Json $ctx @{error='Confirmação explícita de exclusão é obrigatória.'} 409; continue }

            $safePatientId = Sanitize-Part $rawPatientId 'paciente'
            $items = Read-Index
            $patientItems = @($items | Where-Object { [string]$_.patient_id -eq $rawPatientId })
            $remaining = @($items | Where-Object { [string]$_.patient_id -ne $rawPatientId })

            $localFolder = Join-Path $DataRoot ("Pacientes\$safePatientId")
            $backupFolder = if ([string]::IsNullOrWhiteSpace($BackupRoot)) { '' } else { Join-Path $BackupRoot ("Pacientes\$safePatientId") }
            $localRemoved = $false; $backupRemoved = $false
            try {
                if (Test-Path $localFolder) { Remove-Item -LiteralPath $localFolder -Recurse -Force }
                $localRemoved = !(Test-Path $localFolder)
            } catch { Send-Json $ctx @{error=('Não foi possível apagar os arquivos locais do paciente: ' + $_.Exception.Message)} 500; continue }
            try {
                if ($backupFolder -and (Test-Path $backupFolder)) { Remove-Item -LiteralPath $backupFolder -Recurse -Force }
                $backupRemoved = (!$backupFolder -or !(Test-Path $backupFolder))
            } catch { Send-Json $ctx @{error=('Os arquivos locais foram apagados, mas não foi possível apagar a cópia de backup: ' + $_.Exception.Message)} 500; continue }

            Write-Index $remaining
            if ($script:ActiveSession -and [string]$script:ActiveSession.patient_id -eq $rawPatientId) { $script:ActiveSession = $null }
            Send-Json $ctx @{ok=$true;patient_id=$rawPatientId;metadata_removed=$patientItems.Count;local_removed=$localRemoved;backup_removed=$backupRemoved}
            continue
        }

        if ($path -eq '/api/config' -and $method -eq 'POST') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='Acesso local necessário.'} 403; continue }
            $body = Read-JsonBody $ctx
            $newBackup = [string]$body.backup_root
            if (![string]::IsNullOrWhiteSpace($newBackup)) {
                try { New-Item -ItemType Directory -Force -Path $newBackup | Out-Null } catch { Send-Json $ctx @{error='Não foi possível criar/acessar a pasta de backup.'} 400; continue }
            }
            $BackupRoot = $newBackup
            $Config.backup_root = $BackupRoot
            Save-Config $Config
            Send-Json $ctx @{ok=$true;backup_root=$BackupRoot}
            continue
        }

        if ($path -eq '/api/backup/run' -and $method -eq 'POST') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Json $ctx @{error='Acesso local necessário.'} 403; continue }
            if ([string]::IsNullOrWhiteSpace($BackupRoot)) { Send-Json $ctx @{error='Configure uma pasta de backup primeiro.'} 409; continue }
            $items = Read-Index; $copied=0; $failed=0
            foreach($m in $items){
                $st = Copy-ToBackup $m
                if($st -eq 'ok'){ $m.backup_status='ok'; $copied++ }else{ $m.backup_status='failed'; $failed++ }
            }
            Write-Index $items
            Send-Json $ctx @{ok=$true;copied=$copied;failed=$failed}
            continue
        }

        if (($path -like '/media/*' -or $path -like '/thumb/*') -and $method -eq 'GET') {
            if (!(Is-LoopbackRequest $ctx)) { Send-Text $ctx 'Acesso local necessário.' 403; continue }
            $id = [Uri]::UnescapeDataString(($path -split '/')[-1])
            $m = Get-MediaById $id
            if(!$m){ Send-Text $ctx 'Arquivo não encontrado.' 404; continue }
            $isThumb = ($path -like '/thumb/*' -and $m.thumbnail_relative_path)
            $rel = if($isThumb){$m.thumbnail_relative_path}else{$m.relative_path}
            $contentType = if($isThumb){'image/jpeg'}elseif($m.mime_type){[string]$m.mime_type}else{'application/octet-stream'}
            Send-File $ctx (Join-Path $DataRoot $rel) $contentType
            continue
        }

        Send-Json $ctx @{error='Rota não encontrada.'} 404
    } catch {
        try { Send-Json $ctx @{error=$_.Exception.Message} 500 } catch {}
    }
}
