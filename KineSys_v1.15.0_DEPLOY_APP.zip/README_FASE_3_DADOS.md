# KineSys v1.13.0 — Fase 3: governança e migração de dados

## Entrega

Esta versão transforma o armazenamento local em uma camada de contingência controlada:

- inventaria chaves `kinesys_*` existentes no navegador;
- exporta backup JSON antes da migração, restauração ou limpeza;
- restaura somente backups no formato reconhecido pelo KineSys;
- migra prontuários, avaliações e evoluções por ID, usando `upsert` idempotente;
- migra eventos documentais para `public.documentos_timeline` quando a migration SQL estiver aplicada;
- tenta sincronizar filas pendentes de Agenda e Financeiro;
- valida as contagens de pacientes, avaliações, evoluções e documentos na nuvem;
- grava um log auxiliar em `public.kinesys_migracoes_dados`;
- mantém a cópia local até o administrador confirmar a limpeza após validação;
- carrega prontuários locais ainda não migrados sem escondê-los quando a nuvem responde vazia;
- grava novos eventos documentais diretamente na nuvem quando disponível e usa o navegador apenas como contingência.
- mantém a chave do Gemini fora do frontend; relatórios de IA passam pela Edge Function `kinesys-relatorio`.

## Ativação do banco

Execute no SQL Editor do projeto Supabase, nesta ordem:

1. `SUPABASE_MIGRACAO_FASE_3_DADOS_v1.13.0.sql`;
2. confirme as duas linhas de verificação ao final;
3. abra KineSys como administrador e acesse **Configurações → Dados clínicos e backup**;
4. exporte o backup local;
5. execute **Migrar para o Supabase** e aguarde a validação;
6. confira pacientes, avaliações, evoluções e a linha do tempo em outro carregamento;
7. só então, se desejar, use **Remover cópia clínica local**.

## Função segura de IA

O arquivo `supabase/functions/kinesys-relatorio/index.ts` deve ser publicado como Edge Function. Configure no ambiente do projeto a variável secreta `GEMINI_API_KEY` e revogue a chave antiga que estava exposta no protótipo. Enquanto a função não estiver publicada, o relatório manual continua disponível, mas o relatório assistido por IA ficará indisponível.

## Segurança operacional

- Nenhuma chave local é apagada automaticamente.
- A importação altera apenas o armazenamento deste navegador; não sobrescreve o Supabase.
- A limpeza remove somente `kinesys_prontuarios`, `kinesys_documentos_timeline` e `kinesys_pacientes_responsaveis_v1` depois da validação.
- Rascunhos, filas de Agenda e filas Financeiras permanecem locais para não interromper a operação.
- A tabela de documentos contém metadados; bytes de fotos continuam no Windows Local conforme a arquitetura existente.

## Limites desta fase

O isolamento entre clínicas (`clinica_id`) e as políticas RLS específicas por tenant continuam sendo a Fase 2 de segurança multi-clínica. Esta versão centraliza e audita os dados, mas não substitui essa etapa.
