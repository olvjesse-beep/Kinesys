import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const allowedModels = new Set(['gemini-3.6-flash', 'gemini-2.5-flash']);
const allowedRoles = new Set(['MASTER', 'MASTER_FEM', 'FISIOTERAPEUTA', 'PROFISSIONAL', 'MEDICO']);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json; charset=utf-8',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: corsHeaders });
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return json({ error: { message: 'Método não permitido.' } }, 405);

  const authorization = request.headers.get('Authorization') || '';
  if (!authorization.startsWith('Bearer ')) return json({ error: { message: 'Sessão não informada.' } }, 401);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const geminiApiKey = Deno.env.get('GEMINI_API_KEY');
  if (!supabaseUrl || !supabaseAnonKey || !geminiApiKey) {
    return json({ error: { message: 'A função segura de relatório não está configurada.' } }, 503);
  }

  const supabase = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: { Authorization: authorization } },
  });
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError || !authData.user) return json({ error: { message: 'Sessão inválida ou expirada.' } }, 401);

  const { data: profiles, error: profileError } = await supabase
    .from('equipe')
    .select('id,tipo')
    .eq('auth_user_id', authData.user.id)
    .limit(10);
  if (profileError || !(profiles || []).some((profile) => allowedRoles.has(String(profile.tipo || '').toUpperCase()))) {
    return json({ error: { message: 'Este perfil não possui permissão para gerar relatório clínico.' } }, 403);
  }

  let payload: Record<string, unknown>;
  try {
    const raw = await request.text();
    if (raw.length > 250_000) return json({ error: { message: 'Solicitação muito grande.' } }, 413);
    payload = JSON.parse(raw);
  } catch (_) {
    return json({ error: { message: 'JSON inválido.' } }, 400);
  }

  const modelo = String(payload.modelo || '');
  const systemPrompt = String(payload.systemPrompt || '');
  const contents = payload.contents;
  const maxOutputTokens = Math.max(256, Math.min(6000, Number(payload.maxOutputTokens || 5000)));
  if (!allowedModels.has(modelo) || !systemPrompt || !Array.isArray(contents)) {
    return json({ error: { message: 'Parâmetros do relatório inválidos.' } }, 400);
  }

  const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(modelo)}:generateContent?key=${encodeURIComponent(geminiApiKey)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents,
      generationConfig: { maxOutputTokens },
    }),
  });
  const responseBody = await upstream.json().catch(() => ({ error: { message: 'Resposta inválida do provedor.' } }));
  return json(responseBody, upstream.status);
});
