KineSys Clinical v1.15.0 — Fase 1 de direção clínica assistida sobre a Fase 2 multi-clínica e o Design System Etapa 15

ARQUIVO PRINCIPAL
- KineSys.html

DESIGN SYSTEM ATIVO
- design_tokens.css
- design_base.css
- design_responsive.css
- design_foundation.css
- design_features.css
- design_components.css
- design_screens.css
- design_typography.css
- design_navigation.css
- design_agenda.css
- design_clinical.css
- design_utilities.css

O HTML não contém mais blocos <style>. Todos os stylesheets são carregados no <head> na ordem oficial acima.

RECURSOS NECESSÁRIOS
- arquivos JavaScript da raiz;
- database/;
- assets/;
- Windows_Local/ quando utilizado em modo local;
- SUPABASE_SQL/ apenas para configuração/migrações do banco (não é carregado no uso diário).

DOCUMENTAÇÃO FINAL
- README_FASE_1_SEGURANCA.md
- README_FASE_3_DADOS.md
- README_FASE_1_DIRECAO_CLINICA.md
- LGPD_CHECKLIST_PRODUCAO.md
- README_PRODUCAO_ETAPA_15.txt
- AUDITORIA_DESIGN_SYSTEM_ETAPA_15.md
- DESIGN_SYSTEM/ETAPA_15_PRODUCAO/ETAPA_15_METRICAS.json

REGRA DE MANUTENÇÃO
Não reintroduzir CSS inline visual, aliases legados, múltiplos :root ou patches globais concorrentes. Use o módulo semântico correto e tokens --kds-*.

ATIVAÇÃO OBRIGATÓRIA
- Criar/convidar as contas em Supabase Authentication.
- Executar SUPABASE_SQL/SUPABASE_MIGRACAO_FASE_1_AUTH_v1.12.0.sql.
- Executar SUPABASE_SQL/SUPABASE_MIGRACAO_FASE_3_DADOS_v1.13.0.sql.
- Executar SUPABASE_SQL/SUPABASE_MIGRACAO_FASE_2_MULTI_CLINICA_v1.14.0.sql após revisar o backup e confirmar a clínica principal.
- Abrir Configurações → Dados clínicos e backup e concluir a migração validada.
- Não usar esta versão com o banco legado que ainda armazena senhas em public.equipe.

MOTOR CLÍNICO — FASE 1
- A síntese apresenta eixos de investigação, achados compatíveis e incerteza; não confirma diagnóstico automaticamente.
- Campos legados de hipótese permanecem somente para compatibilidade com avaliações já salvas.
