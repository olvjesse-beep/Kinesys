KineSys Clinical v1.11.2 — DESIGN SYSTEM FINAL / PRODUÇÃO
Etapa 15 — 2026-08-29

ABRIR O SISTEMA
- Arquivo principal: KineSys.html
- Mantenha as pastas assets/, database/, Windows_Local/ e os arquivos JS/CSS junto do HTML.

ORDEM OFICIAL DO DESIGN SYSTEM
1. design_tokens.css
2. design_base.css
3. design_responsive.css
4. design_foundation.css
5. design_features.css
6. design_components.css
7. design_screens.css
8. design_typography.css
9. design_navigation.css
10. design_agenda.css
11. design_clinical.css
12. design_utilities.css

REGRAS PARA NÃO DEGRADAR O SISTEMA
- Não criar novos blocos <style> dentro do KineSys.html.
- Não usar tokens antigos --ks-* ou nomes como --azul-petroleo/--texto-secundario.
- Código visual novo deve usar --kds-*.
- Não criar outro CSS global para “corrigir” os módulos existentes.
- Agenda visual pertence a design_agenda.css.
- Avaliação/Motor visual pertence a design_clinical.css.
- Sidebar/Topbar pertencem a design_navigation.css.
- Tipografia pertence a design_typography.css.
- Componentes compartilhados pertencem a design_components.css.
- Utilitários devem ser pequenos, reutilizáveis e ficar em design_utilities.css.

CONTRATO VISUAL CONGELADO
- Corpo 16 px
- Campo 15,5 px / 45 px de altura
- Label 13,5 px
- Navegação 14,5 px
- Título 31 px
- Regiões 17 px
- Nome da região 21 px
- Eixos 18 px
- Achados 15 px
- Agenda compacta 14 px / 42 px

STATUS FINAL
- 0 blocos <style> no HTML
- 0 inline visual estático
- 0 aliases visuais legados
- 0 tokens KDS indefinidos
- 0 conflitos intermodulares de mesma propriedade para o mesmo seletor/contexto
- 22/22 JS de produção com sintaxe válida
- 12/12 CSS externos com parse válido
- 0 IDs duplicados
- 0 referências locais ausentes

IMPORTANTE SOBRE !important
Existem 785 ocorrências ativas. Elas foram mantidas quando a remoção alterava a cascata real. Não removê-las em massa. São dívida de compatibilidade conhecida; qualquer redução futura deve ser feita com teste visual/funcional em navegador real.

AUDITORIA COMPLETA
- AUDITORIA_DESIGN_SYSTEM_ETAPA_15.md
- DESIGN_SYSTEM/ETAPA_15_PRODUCAO/ETAPA_15_METRICAS.json
