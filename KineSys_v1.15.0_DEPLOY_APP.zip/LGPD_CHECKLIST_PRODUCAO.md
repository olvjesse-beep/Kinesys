# KineSys — checklist de proteção de dados para produção

Este documento é um controle operacional. Ele **não é uma certificação jurídica de conformidade**. Dados de saúde são dados pessoais sensíveis; antes de vender o serviço, o controlador deve validar as bases legais, contratos e documentos com profissional especializado.

## Controles técnicos

- [x] Supabase Auth para identidade e sessão.
- [x] Bloqueio da leitura de senha legado pela API.
- [x] RLS inicial da equipe.
- [x] Backup e migração sem exclusão automática.
- [x] Validação de contagens após migração.
- [x] Chave do Gemini removida do frontend.
- [ ] Publicar `kinesys-relatorio` com `GEMINI_API_KEY` em segredo.
- [ ] Restringir CORS da Edge Function ao domínio oficial.
- [ ] Aplicar `clinica_id` e RLS por clínica em todas as tabelas.
- [ ] Ativar MFA para administradores.
- [ ] Configurar backups, retenção, restauração testada e monitoramento.
- [ ] Testar revogação de sessão e recuperação de conta.

## Governança e direitos dos titulares

- [ ] Definir controlador, operador(es) e encarregado/canal de contato.
- [ ] Publicar política de privacidade clara.
- [ ] Registrar finalidade e base legal de cada grupo de dados.
- [ ] Definir prazos de retenção e procedimento de eliminação.
- [ ] Implementar atendimento de acesso, correção, portabilidade e eliminação.
- [ ] Manter registro de operações de tratamento e fornecedores.
- [ ] Criar plano de resposta e comunicação de incidentes.
- [ ] Formalizar contratos com clínicas e fornecedores de infraestrutura/IA.
- [ ] Avaliar necessidade de relatório de impacto à proteção de dados.

## Regra de liberação

Até que todos os itens críticos estejam concluídos e revisados, o KineSys deve ser usado somente com dados de teste ou em piloto controlado. “100% protegido” não é uma afirmação técnica ou jurídica que possa ser garantida por este código isoladamente.
