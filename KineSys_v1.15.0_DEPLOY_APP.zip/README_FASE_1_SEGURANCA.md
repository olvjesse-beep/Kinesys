# KineSys Clinical v1.12.0 — Fase 1 de Segurança

**Base preservada:** KineSys Clinical v1.11.2 / Design System Etapa 15  
**Objetivo:** eliminar o login legado e estabelecer o Supabase Auth como única fonte de identidade e sessão.

## O que esta fase altera

- remove a conta mestra e a senha que estavam incorporadas no JavaScript;
- substitui a consulta de senha na tabela `equipe` por `signInWithPassword` do Supabase Auth;
- deixa de aceitar `localStorage` como prova de autenticação;
- recupera e valida a sessão mantida pelo SDK do Supabase;
- preserva múltiplos perfis/funções associados ao mesmo usuário Auth;
- adiciona solicitação de redefinição de senha por e-mail;
- remove senha da tela de gestão da equipe;
- cria vínculo obrigatório `equipe.auth_user_id -> auth.users.id`;
- preserva temporariamente a coluna legado `equipe.senha`, por decisão do proprietário, mas impede sua leitura e escrita pela API;
- ativa RLS na tabela `equipe` e bloqueia acesso pelo papel `anon`;
- restringe alterações de equipe a perfis administradores autenticados.

## Ativação obrigatória no Supabase

Não abra esta versão para uso real antes de concluir a sequência abaixo.

1. Faça backup do banco.
2. Troque imediatamente a credencial administrativa que existia na v1.11.2 e não volte a utilizá-la.
3. Em **Authentication > Users**, crie ou convide as contas que já deverão acessar a v1.12.0.
4. Confirme que o e-mail da conta Auth é exatamente o mesmo do cadastro em `public.equipe`.
5. Execute `SUPABASE_SQL/SUPABASE_MIGRACAO_FASE_1_AUTH_v1.12.0.sql` no SQL Editor.
6. O resultado final do SQL deve mostrar:
   - `senha_existe = true`, enquanto durar a exceção de compatibilidade solicitada;
   - `perfis_sem_auth` com a quantidade de cadastros preservados que ainda não receberam conta Auth.
7. Configure o **Site URL** e os modelos de e-mail do Supabase Auth para que a redefinição de senha use o endereço publicado do KineSys.
8. Teste login, logout, restauração de sessão, redefinição de senha e cada perfil de acesso.

Perfis sem conta Auth permanecem cadastrados, mas não conseguem entrar na v1.12.0. Suas senhas antigas não são usadas pelo frontend nem ficam disponíveis para os papéis `anon` ou `authenticated` pela API.

## Cadastro de novos membros da equipe

O administrador deve primeiro criar ou convidar o e-mail em **Authentication > Users**. Depois poderá cadastrar o perfil na tela Equipe. O KineSys resolve o UUID da conta pelo e-mail por meio de uma função protegida no banco.

Excluir um perfil na tela Equipe não exclui automaticamente a identidade em Supabase Auth. A remoção definitiva da conta Auth deve ser feita por um administrador autorizado no painel do Supabase até existir uma função backend própria para esse fluxo.

## Validações desta entrega

- nenhuma senha administrativa permanece no frontend;
- nenhuma consulta de login ou operação da API lê `public.equipe.senha`;
- nenhum perfil salvo no navegador concede acesso;
- arquivos JavaScript continuam sujeitos a verificação de sintaxe;
- a ordem e os 12 CSS da Etapa 15 permanecem inalterados.

## Limites conhecidos

Esta fase protege a identidade, a sessão e a tabela de equipe. Ela **não torna o KineSys um SaaS pronto para produção**.

Ainda faltam, entre outros pontos:

- isolamento multi-clínica com `clinica_id`;
- RLS e políticas específicas para pacientes, avaliações, evoluções, agenda, financeiro, documentos e mídias;
- backend seguro para convites e remoção de usuários Auth;
- expiração/revogação administrativa de sessões;
- testes automatizados de autorização;
- revisão do armazenamento local de dados clínicos;
- remoção definitiva da coluna legado `equipe.senha` após a migração de todos os colaboradores;
- auditoria funcional e clínica completa.

Esses itens devem ser tratados nas próximas fases antes de utilizar dados reais de múltiplas clínicas.
