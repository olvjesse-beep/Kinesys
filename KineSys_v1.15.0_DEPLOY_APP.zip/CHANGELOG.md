# Changelog

## v1.15.0 — Fase 1: direção clínica assistida

- O motor passa a se apresentar como apoio à decisão e direcionamento de investigação.
- A síntese trocou linguagem de hipótese confirmada por eixo, direção e achados compatíveis.
- Foi incluído aviso explicativo na síntese clínica: o KineSys não confirma diagnóstico nem substitui o fisioterapeuta.
- A documentação automática passou a declarar que achados compatíveis não estabelecem diagnóstico confirmado.
- Foram adicionados campos semânticos novos (`direcaoInvestigacao`, `codigoEixo`, `nomeEixo`, `eixosAssociados`) sem remover os campos legados.
- Resultados inconclusivos e investigação em aberto continuam disponíveis como desfechos válidos.
- Interface do Exame direcionado reorganizada com hierarquia Clinical Focus: segurança → eixo → próximo exame → decisão profissional.
- Segurança global retirada do topo e convertida em ação compacta no final da etapa 2, com detalhe expansível apenas quando necessário.
- Entrada na etapa 2 corrigida para iniciar no topo da tela, sem impedir a rolagem normal.
- Rotas passaram a usar “Ver sugestões do motor”; biblioteca específica ficou explicitamente opcional.
- Respostas visíveis dos testes foram simplificadas para compatível, não compatível, inconclusivo e não avaliado.
- Motor clínico atualizado de 2.3.2 para 2.4.0.

## v1.14.0 — Fase 2: isolamento multi-clínica

- Preparada migration de tenant com `clinicas`, `membros_clinicas` e `clinica_id` nas tabelas do produto.
- RLS por clínica e vínculo automático dos usuários autenticados.
- Registros existentes associados à clínica principal sem exclusão.
- Atalho administrativo de Configurações preservado no Design System.

## v1.12.0 — Fase 1 de Segurança

- Supabase Auth tornou-se a fonte de identidade e sessão.
- Conta mestra e senha embutidas foram removidas do frontend.
- Login por consulta direta à tabela `equipe` foi removido.
- Sessão de perfil em `localStorage` deixou de conceder acesso.
- Redefinição de senha por e-mail foi adicionada.
- Gestão de equipe deixou de cadastrar ou editar senhas.
- Migração de vínculo `auth.users`/`equipe` e RLS da equipe adicionada.
- A coluna legado de senha foi preservada temporariamente por decisão do proprietário, sem permissão de leitura/escrita pela API e sem uso no login v1.12.0.
- Versão interna do aplicativo atualizada de `1.11.2` para `1.12.0`.
- O menu superior do paciente agora aparece somente nas telas do grupo `ATENDIMENTO`; nas áreas `CLÍNICA` e `GESTÃO`, o paciente permanece selecionado sem exibir o menu flutuante.
- A Avaliação ganhou busca digitável por nome em todos os pacientes, com filtro opcional de pré-cadastros recentes e navegação por teclado.
- A ação `Descartar rascunho` limpa o rascunho automático local e os campos em andamento mediante confirmação, sem excluir avaliações registradas no prontuário.
- O descarte cancela o salvamento automático pendente para impedir que o rascunho apagado seja recriado imediatamente.

O Design System permanece o da Etapa 15, sem alterações de arquitetura visual.
## v1.13.0 — Fase 3: governança e migração de dados

- Criado painel administrativo **Dados clínicos e backup**.
- Inventário de armazenamento local, backup JSON e restauração protegida.
- Migração idempotente de prontuários, avaliações e evoluções para o Supabase.
- Validação por contagem e log auxiliar de migração.
- Criada tabela `documentos_timeline` para eventos documentais do prontuário.
- Dados locais não desaparecem quando a nuvem responde sem o registro; ficam marcados para migração.
- Novos eventos documentais priorizam o Supabase e usam cópia local somente em contingência.
- Limpeza local liberada apenas após migração validada e novo backup automático.
