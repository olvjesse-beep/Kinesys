-- KineSys v1.11.2 — mesma pessoa em múltiplas funções
-- Migração NÃO DESTRUTIVA DE DADOS.
-- Permite repetir e-mail, CPF e registro profissional quando o perfil/função
-- (coluna tipo) for diferente, mantendo unicidade dentro da mesma função.
-- Exemplo permitido: mesmo CPF/e-mail como Administrador e Fisioterapeuta.

begin;

-- Remove apenas os índices antigos de unicidade global criados pelo KineSys v1.8.
-- Nenhum registro da tabela equipe é apagado ou alterado.
drop index if exists public.equipe_email_unique_ci;
drop index if exists public.equipe_cpf_unique;
drop index if exists public.equipe_registro_unique_ci;

-- Evita duplicidade real: mesmo e-mail + mesma função.
create unique index if not exists equipe_email_tipo_unique_ci
    on public.equipe (lower(btrim(email)), upper(btrim(coalesce(tipo,''))))
    where email is not null and btrim(email) <> '';

-- Mesmo CPF pode existir em funções distintas, mas não duas vezes na mesma função.
create unique index if not exists equipe_cpf_tipo_unique
    on public.equipe (
        (regexp_replace(cpf, '[^0-9]', '', 'g')),
        upper(btrim(coalesce(tipo,'')))
    )
    where cpf is not null and regexp_replace(cpf, '[^0-9]', '', 'g') <> '';

-- O mesmo profissional pode reutilizar o próprio registro ao possuir perfis
-- diferentes. Continua proibida a duplicidade do registro dentro da mesma função.
create unique index if not exists equipe_registro_tipo_unique_ci
    on public.equipe (
        (regexp_replace(lower(registro), '\s+', '', 'g')),
        upper(btrim(coalesce(tipo,'')))
    )
    where registro is not null and btrim(registro) <> '' and lower(registro) <> 'secretaria';

commit;
notify pgrst, 'reload schema';

-- Conferência opcional:
select indexname, indexdef
from pg_indexes
where schemaname='public'
  and tablename='equipe'
  and indexname like 'equipe_%unique%'
order by indexname;
