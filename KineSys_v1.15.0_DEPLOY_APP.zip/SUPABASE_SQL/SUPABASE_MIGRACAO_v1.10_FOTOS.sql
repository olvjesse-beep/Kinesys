-- KineSys v1.10 — metadados de fotos/documentos clínicos
-- IMPORTANTE: os arquivos originais NÃO são enviados ao Supabase por esta versão.
-- Eles permanecem no Windows em C:\KineSys\Dados e, se configurado, em uma segunda pasta de backup.

create table if not exists public.arquivos_paciente (
    id text primary key,
    paciente_id text not null references public.pacientes(id) on delete cascade,
    data_hora timestamptz not null default now(),
    tipo text not null default 'outro',
    regiao text,
    descricao text,
    arquivo_nome text,
    caminho_relativo text,
    tamanho_bytes bigint not null default 0,
    mime_type text not null default 'image/jpeg',
    sha256 text,
    backup_status text not null default 'pending',
    profissional_id text,
    profissional_nome text,
    estacao text,
    criado_em timestamptz not null default now(),
    atualizado_em timestamptz not null default now()
);

create index if not exists idx_arquivos_paciente_paciente_data
    on public.arquivos_paciente (paciente_id, data_hora desc);

create index if not exists idx_arquivos_paciente_sha256
    on public.arquivos_paciente (sha256);

-- A arquitetura atual do KineSys ainda usa a chave pública do projeto no navegador.
-- Portanto esta migration NÃO ativa RLS para não interromper o sistema existente.
-- Na etapa de segurança/Supabase Auth, esta tabela deve receber RLS por usuário/estabelecimento.
grant select, insert, update on public.arquivos_paciente to anon, authenticated;

comment on table public.arquivos_paciente is
'Metadados de arquivos clínicos do KineSys. O original permanece em armazenamento local da clínica; esta tabela não contém os bytes da imagem.';
