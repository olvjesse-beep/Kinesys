-- KineSys v1.13.0 — Fase 3: governança e migração de dados locais
--
-- Esta migration cria apenas estruturas novas. Não remove colunas, registros
-- ou a tabela legado public.equipe.senha. A migração do navegador usa upsert
-- por ID e pode ser repetida sem gerar duplicidade.

begin;

create table if not exists public.documentos_timeline (
    id text primary key,
    paciente_id text not null references public.pacientes(id) on delete cascade,
    tipo text not null default 'outro',
    titulo text not null default 'Documento',
    data_hora timestamptz not null default now(),
    emitido_por text not null default '',
    detalhes jsonb not null default '{}'::jsonb,
    criado_em timestamptz not null default now(),
    atualizado_em timestamptz not null default now()
);

create index if not exists documentos_timeline_paciente_data_idx
    on public.documentos_timeline (paciente_id, data_hora desc);

alter table public.documentos_timeline enable row level security;
drop policy if exists documentos_timeline_leitura_autenticada on public.documentos_timeline;
drop policy if exists documentos_timeline_insercao_autenticada on public.documentos_timeline;
drop policy if exists documentos_timeline_atualizacao_autenticada on public.documentos_timeline;
drop policy if exists documentos_timeline_exclusao_autenticada on public.documentos_timeline;

create policy documentos_timeline_leitura_autenticada
on public.documentos_timeline for select to authenticated
using (auth.uid() is not null);

create policy documentos_timeline_insercao_autenticada
on public.documentos_timeline for insert to authenticated
with check (auth.uid() is not null);

create policy documentos_timeline_atualizacao_autenticada
on public.documentos_timeline for update to authenticated
using (auth.uid() is not null)
with check (auth.uid() is not null);

create policy documentos_timeline_exclusao_autenticada
on public.documentos_timeline for delete to authenticated
using (auth.uid() is not null);

revoke all on table public.documentos_timeline from anon;
grant select, insert, update, delete on table public.documentos_timeline to authenticated;

comment on table public.documentos_timeline is
'Eventos documentais do prontuário. Os bytes de fotos permanecem no armazenamento local/Windows Local; esta tabela contém somente o evento e seus metadados.';

create table if not exists public.kinesys_migracoes_dados (
    id uuid primary key default gen_random_uuid(),
    executado_em timestamptz not null default now(),
    executado_por uuid references auth.users(id) on delete set null,
    executado_por_email text not null default '',
    origem text not null default 'navegador',
    versao_aplicacao text not null default '1.13.0',
    pacientes_total integer not null default 0,
    avaliacoes_total integer not null default 0,
    evolucoes_total integer not null default 0,
    documentos_total integer not null default 0,
    validada boolean not null default false,
    detalhes jsonb not null default '{}'::jsonb
);

create index if not exists kinesys_migracoes_dados_data_idx
    on public.kinesys_migracoes_dados (executado_em desc);

alter table public.kinesys_migracoes_dados enable row level security;
drop policy if exists kinesys_migracoes_dados_leitura_autenticada on public.kinesys_migracoes_dados;
drop policy if exists kinesys_migracoes_dados_insercao_autenticada on public.kinesys_migracoes_dados;

create policy kinesys_migracoes_dados_leitura_autenticada
on public.kinesys_migracoes_dados for select to authenticated
using (auth.uid() is not null);

create policy kinesys_migracoes_dados_insercao_autenticada
on public.kinesys_migracoes_dados for insert to authenticated
with check (auth.uid() is not null and executado_por = auth.uid());

revoke all on table public.kinesys_migracoes_dados from anon;
grant select, insert on table public.kinesys_migracoes_dados to authenticated;

commit;

notify pgrst, 'reload schema';

-- Verificação rápida esperada após executar:
select
    to_regclass('public.documentos_timeline') is not null as tabela_documentos_timeline,
    to_regclass('public.kinesys_migracoes_dados') is not null as tabela_log_migracoes;
