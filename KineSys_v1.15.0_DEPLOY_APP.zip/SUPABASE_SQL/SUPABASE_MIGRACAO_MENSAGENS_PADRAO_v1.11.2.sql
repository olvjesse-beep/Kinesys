-- KineSys Clinical v1.11.2
-- ITEM 13 — Mensagens padrão configuráveis pelo Administrador
-- Execute UMA VEZ no Supabase > SQL Editor.
-- Não apaga dados existentes.

begin;

create table if not exists public.configuracoes_mensagens (
    chave text primary key,
    titulo text not null,
    grupo text not null,
    descricao text,
    mensagem text not null,
    ordem integer not null default 100,
    atualizado_em timestamptz not null default now(),
    atualizado_por_id text,
    atualizado_por_nome text
);

create table if not exists public.auditoria_configuracoes_mensagens (
    id bigserial primary key,
    chave text not null,
    alterado_em timestamptz not null default now(),
    alterado_por_id text,
    alterado_por_nome text,
    titulo_anterior text,
    titulo_novo text,
    mensagem_anterior text,
    mensagem_nova text
);

insert into public.configuracoes_mensagens (chave,titulo,grupo,descricao,mensagem,ordem)
values
('crm_checkin_24h','Check-in após 24 horas','CRM e relacionamento','Botão “Check-in (24h)” da Home.','{saudacao}, aqui é {profissional} da {clinica}. Como está a evolução 24 horas após a sessão? A dor melhorou?',10),
('crm_exercicios_3d','Lembrete de exercícios','CRM e relacionamento','Botão “Lembrete Exercícios” da Home.','{saudacao}, aqui é {profissional} da {clinica}. Passando para lembrar dos exercícios que combinamos. Qualquer dúvida, estou à disposição.',20),
('crm_lembrete_sessao','Lembrete de sessão pelo CRM','CRM e relacionamento','Botão “Lembrete Sessão (Pré-24h)” da Home.','{saudacao}, passando para lembrar do atendimento na {clinica}. Faltam aproximadamente {horas} horas para a sessão, marcada para {data} às {hora}. Confirma a presença?',30),
('agenda_lembrete_sessao','Lembrete do agendamento','Agenda','Botão de envio de lembrete dentro do agendamento.','{saudacao}! Passando para lembrar da sessão de {procedimento} no dia {data} às {hora}. {confirmacao}',40),
('agenda_oferta_lista_espera','Oferta de vaga da lista de espera','Agenda','Mensagem enviada ao oferecer uma vaga que acabou de abrir.','{saudacao}! Abriu uma vaga para {procedimento} no dia {data} às {hora}. Há interesse nesse horário? Responda para confirmarmos.',50)
on conflict (chave) do nothing;

create or replace function public.kinesys_auditar_config_mensagem()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    if old.titulo is distinct from new.titulo or old.mensagem is distinct from new.mensagem then
        insert into public.auditoria_configuracoes_mensagens
            (chave, alterado_em, alterado_por_id, alterado_por_nome,
             titulo_anterior, titulo_novo, mensagem_anterior, mensagem_nova)
        values
            (new.chave, now(), new.atualizado_por_id, new.atualizado_por_nome,
             old.titulo, new.titulo, old.mensagem, new.mensagem);
    end if;
    return new;
end;
$$;

drop trigger if exists trg_kinesys_auditar_config_mensagem on public.configuracoes_mensagens;
create trigger trg_kinesys_auditar_config_mensagem
after update on public.configuracoes_mensagens
for each row execute function public.kinesys_auditar_config_mensagem();

-- O aplicativo acessa o catálogo somente pelas funções abaixo. A tabela e a
-- auditoria não ficam disponíveis diretamente pela API pública.
revoke all on table public.configuracoes_mensagens from anon, authenticated;
revoke all on table public.auditoria_configuracoes_mensagens from anon, authenticated;
revoke all on sequence public.auditoria_configuracoes_mensagens_id_seq from anon, authenticated;

create or replace function public.kinesys_listar_mensagens_padrao()
returns table (
    chave text,
    titulo text,
    grupo text,
    descricao text,
    mensagem text,
    ordem integer,
    atualizado_em timestamptz,
    atualizado_por_id text,
    atualizado_por_nome text
)
language sql
security definer
stable
set search_path = public
as $$
    select c.chave,c.titulo,c.grupo,c.descricao,c.mensagem,c.ordem,
           c.atualizado_em,c.atualizado_por_id,c.atualizado_por_nome
      from public.configuracoes_mensagens c
     order by c.ordem, c.chave;
$$;

create or replace function public.kinesys_salvar_mensagem_padrao(
    p_chave text,
    p_titulo text,
    p_mensagem text,
    p_atualizado_por_id text default null,
    p_atualizado_por_nome text default null
)
returns table (
    chave text,
    titulo text,
    grupo text,
    descricao text,
    mensagem text,
    ordem integer,
    atualizado_em timestamptz,
    atualizado_por_id text,
    atualizado_por_nome text
)
language plpgsql
security definer
set search_path = public
as $$
begin
    if p_chave is null or not exists (select 1 from public.configuracoes_mensagens c where c.chave=p_chave) then
        raise exception 'KineSys: modelo de mensagem não reconhecido.' using errcode='22023';
    end if;
    if length(btrim(coalesce(p_mensagem,''))) < 8 then
        raise exception 'KineSys: a mensagem está vazia ou muito curta.' using errcode='22023';
    end if;

    update public.configuracoes_mensagens c
       set titulo = coalesce(nullif(btrim(p_titulo),''), c.titulo),
           mensagem = btrim(p_mensagem),
           atualizado_em = clock_timestamp(),
           atualizado_por_id = nullif(btrim(coalesce(p_atualizado_por_id,'')),''),
           atualizado_por_nome = coalesce(nullif(btrim(p_atualizado_por_nome),''),'Administrador')
     where c.chave = p_chave;

    return query
    select c.chave,c.titulo,c.grupo,c.descricao,c.mensagem,c.ordem,
           c.atualizado_em,c.atualizado_por_id,c.atualizado_por_nome
      from public.configuracoes_mensagens c
     where c.chave = p_chave;
end;
$$;

grant execute on function public.kinesys_listar_mensagens_padrao() to anon, authenticated;
grant execute on function public.kinesys_salvar_mensagem_padrao(text,text,text,text,text) to anon, authenticated;

comment on table public.configuracoes_mensagens is 'Catálogo central de mensagens padrão do KineSys editável na interface administrativa.';
comment on table public.auditoria_configuracoes_mensagens is 'Histórico técnico das alterações nos textos padrão da clínica.';

commit;
