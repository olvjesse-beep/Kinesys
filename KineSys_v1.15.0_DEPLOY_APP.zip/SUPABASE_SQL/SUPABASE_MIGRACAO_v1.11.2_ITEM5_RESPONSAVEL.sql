-- KineSys Clínico v1.11.2 — Item 5
-- Suporte a paciente menor de idade/dependente e contato do responsável.
-- Execute uma única vez no SQL Editor do Supabase para sincronizar estes dados entre dispositivos.

ALTER TABLE public.pacientes
    ADD COLUMN IF NOT EXISTS dependente boolean NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS responsavel_nome text NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS responsavel_parentesco text NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS responsavel_telefone text NOT NULL DEFAULT '';

COMMENT ON COLUMN public.pacientes.dependente IS 'Indica menor de idade ou paciente dependente cujo contato preferencial é o responsável.';
COMMENT ON COLUMN public.pacientes.responsavel_nome IS 'Nome do responsável pelo paciente menor/dependente.';
COMMENT ON COLUMN public.pacientes.responsavel_parentesco IS 'Vínculo/parentesco do responsável com o paciente.';
COMMENT ON COLUMN public.pacientes.responsavel_telefone IS 'Telefone/WhatsApp preferencial do responsável.';
