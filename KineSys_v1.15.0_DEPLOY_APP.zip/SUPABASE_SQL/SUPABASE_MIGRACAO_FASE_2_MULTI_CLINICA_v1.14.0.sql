-- KineSys v1.14.0 — Fase 2: isolamento por clínica (multi-tenant)
--
-- Esta migration cria a clínica principal, associa os registros existentes a
-- ela e ativa RLS por clínica nas tabelas do produto. Não apaga registros nem
-- altera a coluna legado public.equipe.senha.

begin;

create table if not exists public.clinicas (
    id uuid primary key default gen_random_uuid(),
    nome text not null,
    slug text not null unique,
    ativa boolean not null default true,
    criado_em timestamptz not null default now(),
    criado_por uuid references auth.users(id) on delete set null
);

create table if not exists public.membros_clinicas (
    clinica_id uuid not null references public.clinicas(id) on delete cascade,
    auth_user_id uuid not null references auth.users(id) on delete cascade,
    equipe_id text references public.equipe(id) on delete set null,
    papel text not null default 'MEMBRO',
    ativo boolean not null default true,
    criado_em timestamptz not null default now(),
    primary key (clinica_id, auth_user_id),
    unique (clinica_id, equipe_id)
);

insert into public.clinicas (nome, slug, criado_por)
values ('Apta Fisioterapia', 'apta-fisioterapia', auth.uid())
on conflict (slug) do nothing;

create or replace function public.kinesys_current_clinica_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
    select mc.clinica_id
    from public.membros_clinicas mc
    where mc.auth_user_id = auth.uid()
      and mc.ativo = true
    order by mc.criado_em asc
    limit 1
$$;

revoke all on function public.kinesys_current_clinica_id() from public;
grant execute on function public.kinesys_current_clinica_id() to authenticated;

create or replace function public.kinesys_stamp_clinica_id()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    if tg_op = 'UPDATE' then
        if new.clinica_id is null then
            new.clinica_id := old.clinica_id;
        end if;
        if new.clinica_id <> old.clinica_id then
            raise exception 'Não é permitido mover um registro entre clínicas';
        end if;
    elsif new.clinica_id is null then
        new.clinica_id := public.kinesys_current_clinica_id();
    end if;

    if new.clinica_id is null then
        raise exception 'Nenhuma clínica ativa associada à sessão';
    end if;
    return new;
end;
$$;

revoke all on function public.kinesys_stamp_clinica_id() from public;

create or replace function public.kinesys_sync_membro_clinica()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    if new.auth_user_id is not null then
        insert into public.membros_clinicas (clinica_id, auth_user_id, equipe_id, papel, ativo)
        values (new.clinica_id, new.auth_user_id, new.id, coalesce(new.tipo, 'MEMBRO'), coalesce(new.ativo, true))
        on conflict (clinica_id, auth_user_id) do update
        set equipe_id = excluded.equipe_id,
            papel = excluded.papel,
            ativo = excluded.ativo;
    end if;
    return new;
end;
$$;

revoke all on function public.kinesys_sync_membro_clinica() from public;

-- A trigger clínico impede edições de conteúdo após 24 horas. A associação
-- inicial ao tenant é metadado, não altera o conteúdo da avaliação; ele fica
-- temporariamente suspenso somente durante este backfill e é reativado logo
-- depois, dentro da mesma transação.
alter table public.avaliacoes disable trigger trg_kinesys_avaliacoes_24h;

do $$
declare
    v_clinica uuid;
    v_tabela text;
    v_tabelas text[] := array[
        'agendamentos', 'agendamentos_status_historico',
        'analise_pacientes_flags', 'auditoria_configuracoes_mensagens',
        'auditoria_registros_clinicos', 'avaliacoes', 'bloqueios_agenda',
        'configuracoes_mensagens', 'creditos_paciente_usos',
        'despesas_financeiras', 'documentos_timeline', 'equipe', 'evolucoes',
        'horarios_atendimento', 'kinesys_migracoes_dados', 'lista_espera',
        'notificacoes_internas', 'pacientes', 'pagamentos',
        'planos_atendimento', 'procedimentos', 'prontuarios'
    ];
begin
    select id into v_clinica from public.clinicas where slug = 'apta-fisioterapia';
    if v_clinica is null then
        raise exception 'Clínica principal não encontrada';
    end if;

    foreach v_tabela in array v_tabelas loop
        execute format(
            'alter table public.%I add column if not exists clinica_id uuid references public.clinicas(id) on delete restrict',
            v_tabela
        );
        execute format(
            'update public.%I set clinica_id = $1 where clinica_id is null',
            v_tabela
        ) using v_clinica;
        execute format(
            'alter table public.%I alter column clinica_id set default public.kinesys_current_clinica_id()',
            v_tabela
        );
        execute format(
            'alter table public.%I alter column clinica_id set not null',
            v_tabela
        );
        execute format(
            'create index if not exists %I on public.%I (clinica_id)',
            v_tabela || '_clinica_idx', v_tabela
        );
    end loop;
end;
$$;

alter table public.avaliacoes enable trigger trg_kinesys_avaliacoes_24h;

drop trigger if exists kinesys_sync_membro_clinica on public.equipe;
create trigger kinesys_sync_membro_clinica
after insert or update of auth_user_id, tipo, ativo, clinica_id on public.equipe
for each row execute function public.kinesys_sync_membro_clinica();

insert into public.membros_clinicas (clinica_id, auth_user_id, equipe_id, papel)
select c.id, e.auth_user_id, e.id, coalesce(e.tipo, 'MEMBRO')
from public.clinicas c
join public.equipe e on e.auth_user_id is not null
where c.slug = 'apta-fisioterapia'
on conflict (clinica_id, auth_user_id) do update
set equipe_id = excluded.equipe_id,
    papel = excluded.papel,
    ativo = true;

do $$
declare
    v_tabela text;
    v_tabelas text[] := array[
        'agendamentos', 'agendamentos_status_historico',
        'analise_pacientes_flags', 'auditoria_configuracoes_mensagens',
        'auditoria_registros_clinicos', 'avaliacoes', 'bloqueios_agenda',
        'configuracoes_mensagens', 'creditos_paciente_usos',
        'despesas_financeiras', 'documentos_timeline', 'equipe', 'evolucoes',
        'horarios_atendimento', 'kinesys_migracoes_dados', 'lista_espera',
        'notificacoes_internas', 'pacientes', 'pagamentos',
        'planos_atendimento', 'procedimentos', 'prontuarios'
    ];
begin
    foreach v_tabela in array v_tabelas loop
        execute format('drop trigger if exists %I on public.%I', 'kinesys_stamp_clinica_id', v_tabela);
        execute format(
            'create trigger %I before insert or update on public.%I for each row execute function public.kinesys_stamp_clinica_id()',
            'kinesys_stamp_clinica_id', v_tabela
        );
        execute format('alter table public.%I enable row level security', v_tabela);
    end loop;
end;
$$;

-- As políticas antigas destas tabelas eram globais para authenticated. Elas
-- são substituídas pelas políticas tenant abaixo para impedir vazamento entre
-- clínicas.
drop policy if exists equipe_leitura_autenticada on public.equipe;
drop policy if exists equipe_insercao_admin on public.equipe;
drop policy if exists equipe_atualizacao_admin on public.equipe;
drop policy if exists equipe_exclusao_admin on public.equipe;
drop policy if exists documentos_timeline_leitura_autenticada on public.documentos_timeline;
drop policy if exists documentos_timeline_insercao_autenticada on public.documentos_timeline;
drop policy if exists documentos_timeline_atualizacao_autenticada on public.documentos_timeline;
drop policy if exists documentos_timeline_exclusao_autenticada on public.documentos_timeline;
drop policy if exists kinesys_migracoes_dados_leitura_autenticada on public.kinesys_migracoes_dados;
drop policy if exists kinesys_migracoes_dados_insercao_autenticada on public.kinesys_migracoes_dados;

do $$
declare
    v_tabela text;
    v_nome text;
    v_tabelas text[] := array[
        'agendamentos', 'agendamentos_status_historico',
        'analise_pacientes_flags', 'auditoria_configuracoes_mensagens',
        'auditoria_registros_clinicos', 'avaliacoes', 'bloqueios_agenda',
        'configuracoes_mensagens', 'creditos_paciente_usos',
        'despesas_financeiras', 'documentos_timeline', 'equipe', 'evolucoes',
        'horarios_atendimento', 'kinesys_migracoes_dados', 'lista_espera',
        'notificacoes_internas', 'pacientes', 'pagamentos',
        'planos_atendimento', 'procedimentos', 'prontuarios'
    ];
begin
    foreach v_tabela in array v_tabelas loop
        v_nome := 'ks_' || v_tabela;
        execute format('drop policy if exists %I on public.%I', v_nome || '_select', v_tabela);
        execute format('drop policy if exists %I on public.%I', v_nome || '_insert', v_tabela);
        execute format('drop policy if exists %I on public.%I', v_nome || '_update', v_tabela);
        execute format('drop policy if exists %I on public.%I', v_nome || '_delete', v_tabela);

        execute format(
            'create policy %I on public.%I for select to authenticated using (clinica_id = public.kinesys_current_clinica_id())',
            v_nome || '_select', v_tabela
        );
        execute format(
            'create policy %I on public.%I for insert to authenticated with check (clinica_id = public.kinesys_current_clinica_id())',
            v_nome || '_insert', v_tabela
        );
        execute format(
            'create policy %I on public.%I for update to authenticated using (clinica_id = public.kinesys_current_clinica_id()) with check (clinica_id = public.kinesys_current_clinica_id())',
            v_nome || '_update', v_tabela
        );
        execute format(
            'create policy %I on public.%I for delete to authenticated using (clinica_id = public.kinesys_current_clinica_id())',
            v_nome || '_delete', v_tabela
        );

        execute format('revoke all on table public.%I from anon', v_tabela);
        execute format('grant select, insert, update, delete on table public.%I to authenticated', v_tabela);
    end loop;
end;
$$;

alter table public.clinicas enable row level security;
drop policy if exists clinicas_leitura_membro on public.clinicas;
create policy clinicas_leitura_membro
on public.clinicas for select to authenticated
using (id = public.kinesys_current_clinica_id());
revoke all on table public.clinicas from anon;
grant select on table public.clinicas to authenticated;

alter table public.membros_clinicas enable row level security;
drop policy if exists membros_clinicas_leitura_membro on public.membros_clinicas;
create policy membros_clinicas_leitura_membro
on public.membros_clinicas for select to authenticated
using (clinica_id = public.kinesys_current_clinica_id());
revoke all on table public.membros_clinicas from anon;
grant select on table public.membros_clinicas to authenticated;

comment on table public.clinicas is
'Tenants do KineSys. Cada registro clínico deve pertencer a uma clínica.';
comment on table public.membros_clinicas is
'Vínculo entre usuários autenticados e clínicas, usado pela função de RLS.';

commit;

notify pgrst, 'reload schema';

select
    (select count(*) from public.clinicas where slug = 'apta-fisioterapia') as clinica_principal,
    (select count(*) from public.membros_clinicas) as membros_vinculados,
    (select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace
      where n.nspname='public' and c.relname='pacientes' and c.relrowsecurity) as rls_pacientes;
