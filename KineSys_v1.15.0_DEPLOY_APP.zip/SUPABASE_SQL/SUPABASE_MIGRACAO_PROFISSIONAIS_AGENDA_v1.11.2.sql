-- KineSys Clinical v1.11.2
-- Correção 8: controle manual de quem aparece como profissional na Agenda.
-- Não destrutiva e idempotente.

begin;

alter table public.equipe
    add column if not exists aparece_na_agenda boolean;

-- Preserva o comportamento atual para cadastros existentes:
-- Secretaria fica fora; demais perfis que antes apareciam continuam aparecendo.
update public.equipe
set aparece_na_agenda = case
    when upper(btrim(coalesce(tipo, ''))) = 'SECRETARIA' then false
    else true
end
where aparece_na_agenda is null;

alter table public.equipe
    alter column aparece_na_agenda set default false;

alter table public.equipe
    alter column aparece_na_agenda set not null;

comment on column public.equipe.aparece_na_agenda is
    'Definido manualmente pelo administrador. TRUE permite que o colaborador apareça como profissional assistencial nos seletores da Agenda.';

commit;

-- Conferência
select id, nome, tipo, aparece_na_agenda
from public.equipe
order by nome;
