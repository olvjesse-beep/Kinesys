-- KineSys Clinical v1.10.2 — COMPLEMENTO da Agenda do Claude
--
-- IMPORTANTE:
-- Este arquivo NÃO recria procedimentos, horarios_atendimento,
-- bloqueios_agenda nem agendamentos. Ele parte exatamente do schema
-- da Agenda v1.0 já aplicado no Supabase e adiciona somente o que o
-- agenda.js atual utiliza e ainda não existia no SQL original.
--
-- Execute UMA VEZ no Supabase > SQL Editor.
-- Não execute a migration de Agenda v1.10.1 gerada anteriormente pelo KineSys.

-- ==========================================================================
-- ETAPA 1 — CAMPOS DE CONFIRMAÇÃO + LISTA DE ESPERA
-- Esta etapa é idempotente e pode ser reaplicada com segurança.
-- ==========================================================================
begin;

-- O SQL original da Agenda já usa gen_random_uuid().
-- Mantemos token textual opaco para facilitar uso futuro em links.
alter table public.agendamentos
    add column if not exists token_confirmacao text,
    add column if not exists confirmado_pelo_paciente boolean,
    add column if not exists resposta_em timestamptz;

update public.agendamentos
set token_confirmacao = replace(gen_random_uuid()::text, '-', '')
where token_confirmacao is null or btrim(token_confirmacao) = '';

alter table public.agendamentos
    alter column token_confirmacao set default replace(gen_random_uuid()::text, '-', ''),
    alter column token_confirmacao set not null;

create unique index if not exists agendamentos_token_confirmacao_uq
    on public.agendamentos (token_confirmacao);

-- O agenda.js usa esta tabela para fila/reencaixe. IDs/FKs seguem os tipos
-- do schema do Claude: paciente/equipe = TEXT; procedimento = UUID.
create table if not exists public.lista_espera (
    id uuid primary key default gen_random_uuid(),
    paciente_id text not null references public.pacientes(id) on delete cascade,
    profissional_id text references public.equipe(id) on delete cascade,
    procedimento_id uuid references public.procedimentos(id) on delete set null,
    data_preferida date,
    periodo_preferido text not null default 'qualquer'
        check (periodo_preferido in ('manha','tarde','qualquer')),
    observacoes text,
    criado_por text,
    status text not null default 'ativo'
        check (status in ('ativo','cancelado','atendido')),
    criado_em timestamptz not null default now()
);

create index if not exists lista_espera_status_data_idx
    on public.lista_espera (status, data_preferida, criado_em);
create index if not exists lista_espera_paciente_idx
    on public.lista_espera (paciente_id, status);

-- O SQL original não tinha esta validação no banco.
do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname = 'agendamentos_intervalo_valido'
          and conrelid = 'public.agendamentos'::regclass
    ) then
        alter table public.agendamentos
            add constraint agendamentos_intervalo_valido
            check (hora_inicio < hora_fim);
    end if;
end $$;

commit;

-- ==========================================================================
-- ETAPA 2 — TRAVA REAL CONTRA SOBREPOSIÇÃO DE HORÁRIOS
--
-- O índice original (profissional_id, data, hora_inicio) impede apenas dois
-- registros com o MESMO início. Ele não impede, por exemplo:
--   09:00–10:00 e 09:30–10:30.
--
-- A exclusion constraint abaixo bloqueia qualquer interseção de intervalos
-- ativos do mesmo profissional e é segura contra duas inserções concorrentes.
-- ==========================================================================
create extension if not exists btree_gist;

-- Antes de criar a trava, interrompe com mensagem clara se já houver dados
-- antigos sobrepostos. A ETAPA 1 acima já terá sido preservada pelo COMMIT.
do $$
begin
    if exists (
        select 1
        from public.agendamentos a
        join public.agendamentos b
          on a.id::text < b.id::text
         and a.profissional_id = b.profissional_id
         and a.data = b.data
         and a.status <> 'cancelado'
         and b.status <> 'cancelado'
         and a.hora_inicio < b.hora_fim
         and b.hora_inicio < a.hora_fim
    ) then
        raise exception using
            message = 'KineSys Agenda: existem agendamentos ativos sobrepostos. Resolva-os antes de criar a constraint agendamentos_sem_sobreposicao.',
            hint = 'Execute a consulta de auditoria no final deste arquivo para localizar os conflitos e depois rode novamente a ETAPA 2.';
    end if;
end $$;

do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname = 'agendamentos_sem_sobreposicao'
          and conrelid = 'public.agendamentos'::regclass
    ) then
        alter table public.agendamentos
            add constraint agendamentos_sem_sobreposicao
            exclude using gist (
                profissional_id with =,
                tsrange(data + hora_inicio, data + hora_fim, '[)') with &&
            )
            where (status <> 'cancelado');
    end if;
end $$;

-- A nova exclusion constraint já cobre inclusive horários com o mesmo início.
-- Removemos o índice parcial antigo para haver uma única regra autoritativa.
drop index if exists public.agendamentos_sem_conflito;
drop index if exists public.agendamentos_slot_ativo_uq;

-- ==========================================================================
-- VERIFICAÇÃO
-- ==========================================================================
-- 1) Campos esperados:
select column_name, data_type, is_nullable
from information_schema.columns
where table_schema = 'public'
  and table_name = 'agendamentos'
  and column_name in ('token_confirmacao','confirmado_pelo_paciente','resposta_em')
order by column_name;

-- 2) Lista de espera:
select table_name
from information_schema.tables
where table_schema = 'public' and table_name = 'lista_espera';

-- 3) Trava de sobreposição:
select conname
from pg_constraint
where conrelid = 'public.agendamentos'::regclass
  and conname = 'agendamentos_sem_sobreposicao';

-- 4) Auditoria de conflitos existentes (o resultado ideal é ZERO linhas):
select
    a.id as agendamento_a,
    b.id as agendamento_b,
    a.profissional_id,
    a.data,
    a.hora_inicio as inicio_a,
    a.hora_fim as fim_a,
    b.hora_inicio as inicio_b,
    b.hora_fim as fim_b
from public.agendamentos a
join public.agendamentos b
  on a.id::text < b.id::text
 and a.profissional_id = b.profissional_id
 and a.data = b.data
 and a.status <> 'cancelado'
 and b.status <> 'cancelado'
 and a.hora_inicio < b.hora_fim
 and b.hora_inicio < a.hora_fim
order by a.data, a.profissional_id, a.hora_inicio;

-- RLS NÃO é alterado nesta migration.
-- Enquanto o KineSys não migrar o login para Supabase Auth + policies reais,
-- não publique uma página de confirmação self-service usando a mesma chave
-- do painel interno.
