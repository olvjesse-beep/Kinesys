-- KineSys Clinical v1.11.2
-- Exportação de prontuário detalhado: leitura controlada da trilha de auditoria clínica.
-- Execute após a migration de rastreabilidade clínica 24 h (REV2).
-- Não altera nem apaga avaliações/evoluções existentes.

begin;

create or replace function public.kinesys_listar_auditoria_clinica_prontuario(
    p_solicitante_id text,
    p_solicitante_tipo text,
    p_solicitante_nome text,
    p_paciente_id text,
    p_limite integer default 500
)
returns table (
    id bigint,
    tabela text,
    registro_id text,
    paciente_id text,
    alterado_em timestamptz,
    alterado_por_id text,
    alterado_por_nome text,
    antes jsonb,
    depois jsonb
)
language plpgsql
security definer
set search_path = public
as $$
declare
    v_tipo text := upper(btrim(coalesce(p_solicitante_tipo, '')));
    v_autorizado boolean := false;
begin
    if btrim(coalesce(p_paciente_id, '')) = '' then
        raise exception 'KineSys: paciente não informado.' using errcode = '22023';
    end if;

    if v_tipo not in ('MASTER','MASTER_FEM','ADMINISTRADOR','ADMINISTRADORA','FISIOTERAPEUTA','PROFISSIONAL') then
        raise exception 'KineSys: prontuário detalhado restrito a administradores e fisioterapeutas.' using errcode = '42501';
    end if;

    if coalesce(p_solicitante_id, '') = '__master_legado__' then
        if v_tipo not in ('MASTER','MASTER_FEM','ADMINISTRADOR','ADMINISTRADORA')
           or btrim(coalesce(p_solicitante_nome, '')) = '' then
            raise exception 'KineSys: usuário não autorizado.' using errcode = '42501';
        end if;
        v_autorizado := true;
    else
        select exists (
            select 1
              from public.equipe e
             where e.id::text = p_solicitante_id
               and upper(btrim(coalesce(e.tipo, ''))) in ('MASTER','MASTER_FEM','ADMINISTRADOR','ADMINISTRADORA','FISIOTERAPEUTA','PROFISSIONAL')
        ) into v_autorizado;
    end if;

    if not v_autorizado then
        raise exception 'KineSys: usuário não autorizado a consultar a trilha clínica.' using errcode = '42501';
    end if;

    return query
    select
        a.id,
        a.tabela,
        a.registro_id,
        a.paciente_id,
        a.alterado_em,
        a.alterado_por_id,
        a.alterado_por_nome,
        a.antes,
        a.depois
      from public.auditoria_registros_clinicos a
     where a.paciente_id = p_paciente_id
     order by a.alterado_em asc, a.id asc
     limit greatest(1, least(coalesce(p_limite, 500), 1000));
end;
$$;

revoke all on function public.kinesys_listar_auditoria_clinica_prontuario(text,text,text,text,integer) from public;
grant execute on function public.kinesys_listar_auditoria_clinica_prontuario(text,text,text,text,integer) to anon, authenticated;

commit;
