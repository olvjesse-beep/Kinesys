-- KineSys v1.11.2 — Lançamentos de gastos por categoria gerencial
-- Migração NÃO DESTRUTIVA.
-- Pode ser executada mesmo se a migration anterior do balanço ainda não tiver sido rodada.

begin;

create table if not exists public.despesas_financeiras (
    id uuid primary key default gen_random_uuid(),
    descricao text not null,
    categoria text not null default 'Outros',
    subcategoria text,
    valor numeric(12,2) not null check (valor > 0),
    data_despesa date not null default current_date,
    forma_pagamento text,
    observacoes text,
    criado_por text,
    criado_em timestamptz not null default now(),
    operacao_id text
);

alter table public.despesas_financeiras
    add column if not exists subcategoria text;

create unique index if not exists despesas_financeiras_operacao_uidx
    on public.despesas_financeiras (operacao_id) where operacao_id is not null;
create index if not exists despesas_financeiras_data_idx
    on public.despesas_financeiras (data_despesa desc);
create index if not exists despesas_financeiras_categoria_idx
    on public.despesas_financeiras (categoria, data_despesa desc);
create index if not exists despesas_financeiras_subcategoria_idx
    on public.despesas_financeiras (subcategoria, data_despesa desc);

comment on column public.despesas_financeiras.categoria is
'Categoria gerencial do gasto: Contas fixas, Despesas variáveis, Manutenção, Investimento, Marketing, Multas ou Outros.';
comment on column public.despesas_financeiras.subcategoria is
'Detalhe operacional do gasto, por exemplo Água, Energia elétrica, Pró-labore, Simples Nacional, Insumos ou Manutenção de equipamentos.';

-- Mantém compatibilidade com o modelo de autenticação atual do KineSys.
grant select, insert, update, delete on public.despesas_financeiras to anon, authenticated;

commit;
notify pgrst, 'reload schema';

select table_name, column_name, data_type
from information_schema.columns
where table_schema='public' and table_name='despesas_financeiras'
order by ordinal_position;
