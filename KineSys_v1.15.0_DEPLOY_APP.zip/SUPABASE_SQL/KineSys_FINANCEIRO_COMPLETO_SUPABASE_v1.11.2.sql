-- ============================================================================
-- KineSys Clínico v1.11.2 — FINANCEIRO COMPLETO PARA SUPABASE
-- Data: 26/08/2026
--
-- Objetivo:
--   Criar/reparar toda a estrutura que o módulo "Planos e pagamentos" do
--   KineSys v1.11.2 utiliza atualmente, incluindo o vínculo com a Agenda.
--
-- O script é IDEMPOTENTE:
--   - pode ser executado mais de uma vez;
--   - não apaga planos, pagamentos ou agendamentos existentes;
--   - usa IF NOT EXISTS / verificações de constraints sempre que possível.
--
-- PRÉ-REQUISITOS DO KINESYS:
--   public.pacientes      (id TEXT)
--   public.procedimentos  (id UUID)
--   public.agendamentos   (id, paciente_id, procedimento_id, status, data,
--                          hora_inicio)
--
-- IMPORTANTE SOBRE SEGURANÇA:
--   O KineSys v1.11.2 ainda usa login legado no frontend e não Supabase Auth.
--   Por isso as tabelas financeiras abaixo ficam sem RLS, compatível com a
--   arquitetura atual do sistema. Quando o login migrar para Supabase Auth,
--   RLS + policies por perfil devem ser configurados antes de expor o sistema.
-- ============================================================================

begin;

-- --------------------------------------------------------------------------
-- 0) EXTENSÃO PARA UUID
-- --------------------------------------------------------------------------
create extension if not exists pgcrypto;

-- --------------------------------------------------------------------------
-- 1) PRÉ-VOO: NÃO CRIA UMA ESTRUTURA FINANCEIRA "SOLTA"
-- --------------------------------------------------------------------------
do $$
begin
    if to_regclass('public.pacientes') is null then
        raise exception 'KineSys Financeiro: a tabela public.pacientes não existe. Aplique primeiro o schema clínico base.';
    end if;

    if to_regclass('public.procedimentos') is null then
        raise exception 'KineSys Financeiro: a tabela public.procedimentos não existe. Aplique primeiro o schema da Agenda.';
    end if;

    if to_regclass('public.agendamentos') is null then
        raise exception 'KineSys Financeiro: a tabela public.agendamentos não existe. Aplique primeiro o schema da Agenda.';
    end if;

    if not exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='pacientes'
          and column_name='id' and data_type='text'
    ) then
        raise exception 'KineSys Financeiro: public.pacientes.id precisa ser TEXT para esta versão do KineSys.';
    end if;

    if not exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='procedimentos'
          and column_name='id' and data_type='uuid'
    ) then
        raise exception 'KineSys Financeiro: public.procedimentos.id precisa ser UUID para esta versão do KineSys.';
    end if;

    if not exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='agendamentos'
          and column_name='paciente_id'
    ) then
        raise exception 'KineSys Financeiro: falta public.agendamentos.paciente_id.';
    end if;

    if not exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='agendamentos'
          and column_name='procedimento_id'
    ) then
        raise exception 'KineSys Financeiro: falta public.agendamentos.procedimento_id.';
    end if;

    if not exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='agendamentos'
          and column_name='status'
    ) then
        raise exception 'KineSys Financeiro: falta public.agendamentos.status.';
    end if;
end $$;

-- --------------------------------------------------------------------------
-- 2) CAMPOS DE PROCEDIMENTO USADOS PELO FINANCEIRO
--    O financeiro lê: id, nome, valor e ativo.
-- --------------------------------------------------------------------------
alter table public.procedimentos
    add column if not exists valor numeric(12,2),
    add column if not exists ativo boolean not null default true;

-- --------------------------------------------------------------------------
-- 3) PLANOS / PACOTES DE ATENDIMENTO
-- --------------------------------------------------------------------------
create table if not exists public.planos_atendimento (
    id uuid primary key default gen_random_uuid(),
    paciente_id text not null,
    procedimento_id uuid,
    nome text not null,
    sessoes_contratadas integer not null,
    valor_tabela numeric(12,2) not null default 0,
    desconto_valor numeric(12,2) not null default 0,
    valor_final numeric(12,2) not null default 0,
    forma_pagamento_prevista text,
    parcelas integer not null default 1,
    observacoes text,
    status text not null default 'ativo',
    criado_por text,
    criado_em timestamptz not null default now(),
    encerrado_em timestamptz,
    operacao_id text
);

-- Reparo de instalações parciais/antigas.
alter table public.planos_atendimento
    add column if not exists id uuid default gen_random_uuid(),
    add column if not exists paciente_id text,
    add column if not exists procedimento_id uuid,
    add column if not exists nome text,
    add column if not exists sessoes_contratadas integer,
    add column if not exists valor_tabela numeric(12,2) default 0,
    add column if not exists desconto_valor numeric(12,2) default 0,
    add column if not exists valor_final numeric(12,2) default 0,
    add column if not exists forma_pagamento_prevista text,
    add column if not exists parcelas integer default 1,
    add column if not exists observacoes text,
    add column if not exists status text default 'ativo',
    add column if not exists criado_por text,
    add column if not exists criado_em timestamptz default now(),
    add column if not exists encerrado_em timestamptz,
    add column if not exists operacao_id text;

-- Backfill apenas de NULLs de instalações incompletas; não altera valores válidos.
update public.planos_atendimento set id = gen_random_uuid() where id is null;
update public.planos_atendimento set nome = 'Plano de atendimento' where nome is null or btrim(nome)='';
update public.planos_atendimento set sessoes_contratadas = 1 where sessoes_contratadas is null;
update public.planos_atendimento set valor_tabela = 0 where valor_tabela is null;
update public.planos_atendimento set desconto_valor = 0 where desconto_valor is null;
update public.planos_atendimento set valor_final = greatest(0, coalesce(valor_tabela,0)-coalesce(desconto_valor,0)) where valor_final is null;
update public.planos_atendimento set parcelas = 1 where parcelas is null;
update public.planos_atendimento set status = 'ativo' where status is null or btrim(status)='';
update public.planos_atendimento set criado_em = now() where criado_em is null;

alter table public.planos_atendimento
    alter column id set default gen_random_uuid(),
    alter column paciente_id set not null,
    alter column nome set not null,
    alter column sessoes_contratadas set not null,
    alter column valor_tabela set default 0,
    alter column valor_tabela set not null,
    alter column desconto_valor set default 0,
    alter column desconto_valor set not null,
    alter column valor_final set default 0,
    alter column valor_final set not null,
    alter column parcelas set default 1,
    alter column parcelas set not null,
    alter column status set default 'ativo',
    alter column status set not null,
    alter column criado_em set default now(),
    alter column criado_em set not null;

-- Garante PK caso a tabela tivesse sido criada manualmente sem uma.
do $$
begin
    if not exists (
        select 1
        from pg_constraint
        where conrelid='public.planos_atendimento'::regclass
          and contype='p'
    ) then
        alter table public.planos_atendimento
            add constraint planos_atendimento_pkey primary key (id);
    end if;
end $$;

-- Constraints de integridade equivalentes ao comportamento do KineSys.
do $$
begin
    if not exists (select 1 from pg_constraint where conname='planos_atendimento_sessoes_ck' and conrelid='public.planos_atendimento'::regclass) then
        alter table public.planos_atendimento add constraint planos_atendimento_sessoes_ck check (sessoes_contratadas > 0);
    end if;
    if not exists (select 1 from pg_constraint where conname='planos_atendimento_valor_tabela_ck' and conrelid='public.planos_atendimento'::regclass) then
        alter table public.planos_atendimento add constraint planos_atendimento_valor_tabela_ck check (valor_tabela >= 0);
    end if;
    if not exists (select 1 from pg_constraint where conname='planos_atendimento_desconto_ck' and conrelid='public.planos_atendimento'::regclass) then
        alter table public.planos_atendimento add constraint planos_atendimento_desconto_ck check (desconto_valor >= 0);
    end if;
    if not exists (select 1 from pg_constraint where conname='planos_atendimento_valor_final_ck' and conrelid='public.planos_atendimento'::regclass) then
        alter table public.planos_atendimento add constraint planos_atendimento_valor_final_ck check (valor_final >= 0);
    end if;
    if not exists (select 1 from pg_constraint where conname='planos_atendimento_parcelas_ck' and conrelid='public.planos_atendimento'::regclass) then
        alter table public.planos_atendimento add constraint planos_atendimento_parcelas_ck check (parcelas > 0);
    end if;
    if not exists (select 1 from pg_constraint where conname='planos_atendimento_status_ck' and conrelid='public.planos_atendimento'::regclass) then
        alter table public.planos_atendimento add constraint planos_atendimento_status_ck check (status in ('ativo','concluido','cancelado'));
    end if;
end $$;

-- FKs dos planos.
do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname='planos_atendimento_paciente_id_fkey'
          and conrelid='public.planos_atendimento'::regclass
    ) then
        alter table public.planos_atendimento
            add constraint planos_atendimento_paciente_id_fkey
            foreign key (paciente_id) references public.pacientes(id) on delete cascade;
    end if;

    if not exists (
        select 1 from pg_constraint
        where conname='planos_atendimento_procedimento_id_fkey'
          and conrelid='public.planos_atendimento'::regclass
    ) then
        alter table public.planos_atendimento
            add constraint planos_atendimento_procedimento_id_fkey
            foreign key (procedimento_id) references public.procedimentos(id) on delete set null;
    end if;
end $$;

-- Índices: paciente/status para carregamento e operacao_id para impedir
-- duplicidade quando um registro local é sincronizado depois.
create unique index if not exists planos_atendimento_operacao_uidx
    on public.planos_atendimento (operacao_id)
    where operacao_id is not null;

create index if not exists planos_atendimento_paciente_idx
    on public.planos_atendimento (paciente_id, status);

create index if not exists planos_atendimento_procedimento_idx
    on public.planos_atendimento (procedimento_id)
    where procedimento_id is not null;

create index if not exists planos_atendimento_criado_em_idx
    on public.planos_atendimento (paciente_id, criado_em desc);

-- --------------------------------------------------------------------------
-- 4) PAGAMENTOS / RECEBIMENTOS
--    Múltiplas formas são gravadas em TEXT, ex.: "PIX + Cartão de crédito".
-- --------------------------------------------------------------------------
create table if not exists public.pagamentos (
    id uuid primary key default gen_random_uuid(),
    plano_id uuid not null,
    paciente_id text not null,
    valor numeric(12,2) not null,
    forma_pagamento text not null,
    data_pagamento date not null default current_date,
    observacoes text,
    criado_por text,
    criado_em timestamptz not null default now(),
    operacao_id text
);

-- Reparo de instalações parciais/antigas.
alter table public.pagamentos
    add column if not exists id uuid default gen_random_uuid(),
    add column if not exists plano_id uuid,
    add column if not exists paciente_id text,
    add column if not exists valor numeric(12,2),
    add column if not exists forma_pagamento text,
    add column if not exists data_pagamento date default current_date,
    add column if not exists observacoes text,
    add column if not exists criado_por text,
    add column if not exists criado_em timestamptz default now(),
    add column if not exists operacao_id text;

update public.pagamentos set id = gen_random_uuid() where id is null;
update public.pagamentos set data_pagamento = current_date where data_pagamento is null;
update public.pagamentos set criado_em = now() where criado_em is null;

alter table public.pagamentos
    alter column id set default gen_random_uuid(),
    alter column plano_id set not null,
    alter column paciente_id set not null,
    alter column valor set not null,
    alter column forma_pagamento set not null,
    alter column data_pagamento set default current_date,
    alter column data_pagamento set not null,
    alter column criado_em set default now(),
    alter column criado_em set not null;

do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conrelid='public.pagamentos'::regclass
          and contype='p'
    ) then
        alter table public.pagamentos
            add constraint pagamentos_pkey primary key (id);
    end if;

    if not exists (select 1 from pg_constraint where conname='pagamentos_valor_ck' and conrelid='public.pagamentos'::regclass) then
        alter table public.pagamentos add constraint pagamentos_valor_ck check (valor > 0);
    end if;
end $$;

-- FKs dos pagamentos.
do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname='pagamentos_plano_id_fkey'
          and conrelid='public.pagamentos'::regclass
    ) then
        alter table public.pagamentos
            add constraint pagamentos_plano_id_fkey
            foreign key (plano_id) references public.planos_atendimento(id) on delete restrict;
    end if;

    if not exists (
        select 1 from pg_constraint
        where conname='pagamentos_paciente_id_fkey'
          and conrelid='public.pagamentos'::regclass
    ) then
        alter table public.pagamentos
            add constraint pagamentos_paciente_id_fkey
            foreign key (paciente_id) references public.pacientes(id) on delete cascade;
    end if;
end $$;

create unique index if not exists pagamentos_operacao_uidx
    on public.pagamentos (operacao_id)
    where operacao_id is not null;

create index if not exists pagamentos_paciente_idx
    on public.pagamentos (paciente_id, data_pagamento desc);

create index if not exists pagamentos_plano_idx
    on public.pagamentos (plano_id, data_pagamento desc);

create index if not exists pagamentos_criado_em_idx
    on public.pagamentos (paciente_id, criado_em desc);

-- --------------------------------------------------------------------------
-- 5) VÍNCULO FINANCEIRO COM A AGENDA
-- --------------------------------------------------------------------------
alter table public.agendamentos
    add column if not exists plano_id uuid;

do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname='agendamentos_plano_id_fkey'
          and conrelid='public.agendamentos'::regclass
    ) then
        alter table public.agendamentos
            add constraint agendamentos_plano_id_fkey
            foreign key (plano_id) references public.planos_atendimento(id) on delete set null;
    end if;
end $$;

create index if not exists agendamentos_plano_idx
    on public.agendamentos (plano_id, status)
    where plano_id is not null;

-- --------------------------------------------------------------------------
-- 6) INTEGRIDADE: PAGAMENTO TEM DE PERTENCER AO MESMO PACIENTE DO PLANO
-- --------------------------------------------------------------------------
create or replace function public.kinesys_validar_pagamento_plano_paciente()
returns trigger
language plpgsql
set search_path = public
as $$
declare
    v_paciente_id text;
begin
    select paciente_id
      into v_paciente_id
      from public.planos_atendimento
     where id = new.plano_id;

    if v_paciente_id is null then
        raise exception 'KineSys Financeiro: plano % não encontrado.', new.plano_id;
    end if;

    if new.paciente_id is distinct from v_paciente_id then
        raise exception 'KineSys Financeiro: o pagamento não pertence ao mesmo paciente do plano.';
    end if;

    return new;
end;
$$;

drop trigger if exists trg_kinesys_pagamento_plano_paciente on public.pagamentos;
create trigger trg_kinesys_pagamento_plano_paciente
before insert or update of plano_id, paciente_id
on public.pagamentos
for each row
execute function public.kinesys_validar_pagamento_plano_paciente();

-- --------------------------------------------------------------------------
-- 7) INTEGRIDADE: PACOTE VINCULADO À AGENDA TEM DE SER DO MESMO PACIENTE
--    E, QUANDO O PACOTE É ESPECÍFICO, DO MESMO PROCEDIMENTO.
-- --------------------------------------------------------------------------
create or replace function public.kinesys_validar_agendamento_plano()
returns trigger
language plpgsql
set search_path = public
as $$
declare
    v_paciente_id text;
    v_procedimento_id uuid;
    v_status text;
begin
    if new.plano_id is null then
        return new;
    end if;

    select paciente_id, procedimento_id, status
      into v_paciente_id, v_procedimento_id, v_status
      from public.planos_atendimento
     where id = new.plano_id;

    if v_paciente_id is null then
        raise exception 'KineSys Agenda: pacote % não encontrado.', new.plano_id;
    end if;

    if new.paciente_id is distinct from v_paciente_id then
        raise exception 'KineSys Agenda: o pacote selecionado pertence a outro paciente.';
    end if;

    if v_procedimento_id is not null
       and new.procedimento_id is distinct from v_procedimento_id then
        raise exception 'KineSys Agenda: o pacote selecionado é específico para outro procedimento.';
    end if;

    -- Só impede NOVO vínculo a um plano encerrado/cancelado. Atualizar o status
    -- de uma sessão antiga já vinculada continua permitido.
    if tg_op = 'INSERT' then
        if v_status <> 'ativo' then
            raise exception 'KineSys Agenda: o pacote selecionado não está ativo.';
        end if;
    elsif new.plano_id is distinct from old.plano_id then
        if v_status <> 'ativo' then
            raise exception 'KineSys Agenda: o pacote selecionado não está ativo.';
        end if;
    end if;

    return new;
end;
$$;

drop trigger if exists trg_kinesys_agendamento_plano on public.agendamentos;
create trigger trg_kinesys_agendamento_plano
before insert or update of plano_id, paciente_id, procedimento_id
on public.agendamentos
for each row
execute function public.kinesys_validar_agendamento_plano();

-- --------------------------------------------------------------------------
-- 8) ENCERRAMENTO AUTOMÁTICO DO PACOTE QUANDO TODAS AS SESSÕES FOREM CONCLUÍDAS
--    O frontend já faz esta verificação; o trigger abaixo adiciona uma segunda
--    camada de consistência no banco.
-- --------------------------------------------------------------------------
create or replace function public.kinesys_recalcular_encerramento_plano()
returns trigger
language plpgsql
set search_path = public
as $$
declare
    v_plano_id uuid;
    v_contratadas integer;
    v_realizadas integer;
begin
    if tg_op = 'DELETE' then
        v_plano_id := old.plano_id;
    elsif tg_op = 'INSERT' then
        v_plano_id := new.plano_id;
    else
        v_plano_id := coalesce(new.plano_id, old.plano_id);
    end if;

    if v_plano_id is null then
        return null;
    end if;

    select sessoes_contratadas
      into v_contratadas
      from public.planos_atendimento
     where id = v_plano_id
       and status = 'ativo';

    if v_contratadas is null then
        return null;
    end if;

    select count(*)
      into v_realizadas
      from public.agendamentos
     where plano_id = v_plano_id
       and status = 'concluido';

    if v_realizadas >= v_contratadas then
        update public.planos_atendimento
           set status = 'concluido',
               encerrado_em = coalesce(encerrado_em, now())
         where id = v_plano_id
           and status = 'ativo';
    end if;

    -- AFTER trigger: o valor de retorno é ignorado.
    return null;
end;
$$;

drop trigger if exists trg_kinesys_encerrar_plano_agendamento on public.agendamentos;
create trigger trg_kinesys_encerrar_plano_agendamento
after insert or update of status, plano_id or delete
on public.agendamentos
for each row
execute function public.kinesys_recalcular_encerramento_plano();

-- --------------------------------------------------------------------------
-- 9) ACESSO COMPATÍVEL COM O LOGIN LEGADO ATUAL DO KINESYS
-- --------------------------------------------------------------------------
-- O painel atual usa a chave pública/anon do Supabase e controla permissões
-- dentro do próprio KineSys. Por isso NÃO ative RLS nestas duas tabelas agora.
alter table public.planos_atendimento disable row level security;
alter table public.pagamentos disable row level security;

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.planos_atendimento to anon, authenticated;
grant select, insert, update, delete on public.pagamentos to anon, authenticated;
grant execute on function public.kinesys_validar_pagamento_plano_paciente() to anon, authenticated;
grant execute on function public.kinesys_validar_agendamento_plano() to anon, authenticated;
grant execute on function public.kinesys_recalcular_encerramento_plano() to anon, authenticated;

commit;

-- --------------------------------------------------------------------------
-- 10) PEDE AO POSTGREST/SUPABASE PARA RECARREGAR O SCHEMA
-- --------------------------------------------------------------------------
notify pgrst, 'reload schema';

-- --------------------------------------------------------------------------
-- 11) VERIFICAÇÃO FINAL — DEVE RETORNAR "OK" NAS LINHAS PRINCIPAIS
-- --------------------------------------------------------------------------
select
    'planos_atendimento' as item,
    case when to_regclass('public.planos_atendimento') is not null then 'OK' else 'FALTA' end as status
union all
select
    'pagamentos',
    case when to_regclass('public.pagamentos') is not null then 'OK' else 'FALTA' end
union all
select
    'agendamentos.plano_id',
    case when exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='agendamentos' and column_name='plano_id'
    ) then 'OK' else 'FALTA' end
union all
select
    'procedimentos.valor',
    case when exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='procedimentos' and column_name='valor'
    ) then 'OK' else 'FALTA' end
union all
select
    'procedimentos.ativo',
    case when exists (
        select 1 from information_schema.columns
        where table_schema='public' and table_name='procedimentos' and column_name='ativo'
    ) then 'OK' else 'FALTA' end;

-- Mostra as colunas financeiras criadas.
select table_name, column_name, data_type, is_nullable
from information_schema.columns
where table_schema='public'
  and (
      table_name in ('planos_atendimento','pagamentos')
      or (table_name='agendamentos' and column_name='plano_id')
  )
order by table_name, ordinal_position;

-- Mostra as FKs principais do Financeiro.
select
    conrelid::regclass::text as tabela,
    conname as constraint_name,
    pg_get_constraintdef(oid) as definicao
from pg_constraint
where conname in (
    'planos_atendimento_paciente_id_fkey',
    'planos_atendimento_procedimento_id_fkey',
    'pagamentos_plano_id_fkey',
    'pagamentos_paciente_id_fkey',
    'agendamentos_plano_id_fkey'
)
order by tabela, constraint_name;

-- FIM — KineSys Financeiro completo v1.11.2
