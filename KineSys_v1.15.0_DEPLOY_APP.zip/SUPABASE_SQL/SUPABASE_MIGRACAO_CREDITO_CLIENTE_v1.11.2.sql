-- ============================================================================
-- KineSys Clínico v1.11.2 — CRÉDITO DO PACIENTE
-- Migração não destrutiva: registra apenas a UTILIZAÇÃO do crédito.
-- O crédito disponível é calculado pelo KineSys a partir de pagamentos que
-- excederam o valor devido dos planos/cobranças, menos os usos abaixo.
-- ============================================================================

begin;
create extension if not exists pgcrypto;

do $$
begin
    if to_regclass('public.pacientes') is null then
        raise exception 'KineSys Crédito: public.pacientes não existe.';
    end if;
    if to_regclass('public.planos_atendimento') is null then
        raise exception 'KineSys Crédito: public.planos_atendimento não existe. Aplique primeiro o Financeiro Completo.';
    end if;
end $$;

create table if not exists public.creditos_paciente_usos (
    id uuid primary key default gen_random_uuid(),
    paciente_id text not null,
    plano_id uuid not null,
    valor numeric(12,2) not null,
    data_uso date not null default current_date,
    observacoes text,
    criado_por text,
    criado_em timestamptz not null default now(),
    operacao_id text
);

alter table public.creditos_paciente_usos
    add column if not exists id uuid default gen_random_uuid(),
    add column if not exists paciente_id text,
    add column if not exists plano_id uuid,
    add column if not exists valor numeric(12,2),
    add column if not exists data_uso date default current_date,
    add column if not exists observacoes text,
    add column if not exists criado_por text,
    add column if not exists criado_em timestamptz default now(),
    add column if not exists operacao_id text;

do $$
begin
    if not exists (select 1 from pg_constraint where conname='creditos_paciente_usos_valor_ck' and conrelid='public.creditos_paciente_usos'::regclass) then
        alter table public.creditos_paciente_usos add constraint creditos_paciente_usos_valor_ck check (valor > 0);
    end if;
    if not exists (select 1 from pg_constraint where conname='creditos_paciente_usos_paciente_fkey' and conrelid='public.creditos_paciente_usos'::regclass) then
        alter table public.creditos_paciente_usos add constraint creditos_paciente_usos_paciente_fkey foreign key (paciente_id) references public.pacientes(id) on delete cascade;
    end if;
    if not exists (select 1 from pg_constraint where conname='creditos_paciente_usos_plano_fkey' and conrelid='public.creditos_paciente_usos'::regclass) then
        alter table public.creditos_paciente_usos add constraint creditos_paciente_usos_plano_fkey foreign key (plano_id) references public.planos_atendimento(id) on delete restrict;
    end if;
end $$;

create unique index if not exists creditos_paciente_usos_operacao_uidx
    on public.creditos_paciente_usos (operacao_id) where operacao_id is not null;
create index if not exists creditos_paciente_usos_paciente_idx
    on public.creditos_paciente_usos (paciente_id, data_uso desc);
create index if not exists creditos_paciente_usos_plano_idx
    on public.creditos_paciente_usos (plano_id, data_uso desc);

create or replace function public.kinesys_validar_credito_plano_paciente()
returns trigger
language plpgsql
set search_path=public
as $$
declare v_paciente text;
begin
    select paciente_id into v_paciente from public.planos_atendimento where id=new.plano_id;
    if v_paciente is null then raise exception 'KineSys Crédito: plano % não encontrado.',new.plano_id; end if;
    if new.paciente_id is distinct from v_paciente then raise exception 'KineSys Crédito: plano pertence a outro paciente.'; end if;
    return new;
end;
$$;

drop trigger if exists trg_kinesys_credito_plano_paciente on public.creditos_paciente_usos;
create trigger trg_kinesys_credito_plano_paciente
before insert or update of paciente_id,plano_id on public.creditos_paciente_usos
for each row execute function public.kinesys_validar_credito_plano_paciente();

-- Compatível com a arquitetura atual do KineSys v1.11.2, que ainda não usa
-- Supabase Auth no login do frontend. Reavaliar RLS quando o login migrar.
alter table public.creditos_paciente_usos disable row level security;

commit;
