-- KineSys v1.11.2 — Aba de Análise Administrativa
-- Migração NÃO DESTRUTIVA.
-- Cria a tabela que permite ao ADM marcar manualmente quais pacientes
-- entram no indicador "novos pacientes" da análise anual.

begin;

create table if not exists public.analise_pacientes_flags (
    id uuid primary key default gen_random_uuid(),
    paciente_id text not null,
    ano_referencia integer not null,
    selecionado boolean not null default true,
    marcado_em timestamptz not null default now(),
    marcado_por text,
    observacoes text,
    operacao_id text
);

create unique index if not exists analise_pacientes_flags_paciente_ano_uidx
    on public.analise_pacientes_flags (paciente_id, ano_referencia);
create unique index if not exists analise_pacientes_flags_operacao_uidx
    on public.analise_pacientes_flags (operacao_id)
    where operacao_id is not null;
create index if not exists analise_pacientes_flags_ano_idx
    on public.analise_pacientes_flags (ano_referencia desc, selecionado);
create index if not exists analise_pacientes_flags_paciente_idx
    on public.analise_pacientes_flags (paciente_id);

comment on table public.analise_pacientes_flags is
'Permite ao administrador escolher manualmente quais pacientes entram no indicador de novos pacientes da aba Análise do KineSys.';

-- Compatível com o modelo atual do frontend.
grant select, insert, update, delete on public.analise_pacientes_flags to anon, authenticated;

commit;
notify pgrst, 'reload schema';

select table_name, column_name, data_type
from information_schema.columns
where table_schema='public' and table_name='analise_pacientes_flags'
order by ordinal_position;
