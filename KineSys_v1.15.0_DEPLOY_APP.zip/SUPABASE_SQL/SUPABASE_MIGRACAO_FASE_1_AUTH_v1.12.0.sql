-- KineSys Clinical v1.12.0 — Fase 1: autenticação segura
--
-- Perfis que já possuam uma conta em Supabase Authentication > Users serão
-- vinculados automaticamente pelo e-mail. Perfis ainda sem conta Auth ficam
-- preservados, com auth_user_id nulo e sem acesso ao frontend v1.12.0.
--
-- EFEITOS
-- 1. vincula public.equipe a auth.users por UUID;
-- 2. preserva temporariamente a coluna legado public.equipe.senha por decisão
--    do proprietário, mas revoga sua leitura/escrita pela API;
-- 3. ativa RLS na equipe e bloqueia o papel anon;
-- 4. limita gravações da equipe a perfis administradores autenticados;
-- 5. cria uma função segura para o administrador vincular novos perfis.

begin;

lock table public.equipe in share row exclusive mode;

alter table public.equipe
    add column if not exists auth_user_id uuid;

update public.equipe e
   set auth_user_id = u.id
  from auth.users u
 where lower(btrim(u.email)) = lower(btrim(e.email))
   and e.auth_user_id is distinct from u.id;

create index if not exists equipe_auth_user_id_idx
    on public.equipe (auth_user_id);

comment on column public.equipe.auth_user_id is
    'Identidade autenticada pelo Supabase Auth. Um usuário pode possuir mais de um perfil/função KineSys.';

create or replace function public.kinesys_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
    select exists (
        select 1
          from public.equipe e
         where e.auth_user_id = auth.uid()
           and upper(btrim(coalesce(e.tipo, ''))) in ('MASTER', 'MASTER_FEM')
    );
$$;

revoke all on function public.kinesys_is_admin() from public, anon;
grant execute on function public.kinesys_is_admin() to authenticated;

create or replace function public.kinesys_validar_vinculo_auth_equipe()
returns trigger
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
begin
    if new.auth_user_id is null then
        return new;
    end if;
    if not exists (
        select 1
          from auth.users u
         where u.id = new.auth_user_id
           and lower(btrim(u.email)) = lower(btrim(new.email))
    ) then
        raise exception 'O perfil da equipe deve usar o mesmo e-mail da conta Supabase Auth vinculada.';
    end if;
    return new;
end;
$$;

drop trigger if exists equipe_validar_vinculo_auth on public.equipe;
create trigger equipe_validar_vinculo_auth
before insert or update of auth_user_id, email on public.equipe
for each row execute function public.kinesys_validar_vinculo_auth_equipe();

create or replace function public.kinesys_resolver_auth_user_id(p_email text)
returns uuid
language plpgsql
stable
security definer
set search_path = public, auth, pg_temp
as $$
declare
    resultado uuid;
begin
    if not public.kinesys_is_admin() then
        raise exception 'Apenas administradores autenticados podem vincular perfis.';
    end if;

    select u.id
      into resultado
      from auth.users u
     where lower(btrim(u.email)) = lower(btrim(p_email))
     limit 1;

    if resultado is null then
        raise exception 'Nenhuma conta Supabase Auth foi encontrada para o e-mail informado.';
    end if;

    return resultado;
end;
$$;

revoke all on function public.kinesys_resolver_auth_user_id(text) from public, anon;
grant execute on function public.kinesys_resolver_auth_user_id(text) to authenticated;

alter table public.equipe enable row level security;

-- Substitui políticas legadas/permissivas por um conjunto conhecido da Fase 1.
do $$
declare
    politica record;
begin
    for politica in
        select policyname
          from pg_policies
         where schemaname = 'public'
           and tablename = 'equipe'
    loop
        execute format('drop policy if exists %I on public.equipe', politica.policyname);
    end loop;
end
$$;

-- Nesta baseline ainda existe apenas uma clínica por projeto Supabase. A Fase 2
-- substituirá esta política pelo isolamento multi-clínica via clinica_id.
create policy equipe_leitura_autenticada
on public.equipe
for select
to authenticated
using (auth.uid() is not null);

create policy equipe_insercao_admin
on public.equipe
for insert
to authenticated
with check (public.kinesys_is_admin());

create policy equipe_atualizacao_admin
on public.equipe
for update
to authenticated
using (public.kinesys_is_admin())
with check (public.kinesys_is_admin());

create policy equipe_exclusao_admin
on public.equipe
for delete
to authenticated
using (public.kinesys_is_admin());

revoke all on table public.equipe from anon;
revoke all on table public.equipe from authenticated;
-- A senha legado continua fisicamente preservada, porém não é concedida à API.
grant select (
    id, auth_user_id, nome, email, tipo, registro, conselho, regional,
    numero_registro, aparece_na_agenda, idade, endereco, cpf
) on public.equipe to authenticated;
grant insert (
    id, auth_user_id, nome, email, tipo, registro, conselho, regional,
    numero_registro, aparece_na_agenda, idade, endereco, cpf
) on public.equipe to authenticated;
grant update (
    auth_user_id, nome, email, tipo, registro, conselho, regional,
    numero_registro, aparece_na_agenda, idade, endereco, cpf
) on public.equipe to authenticated;
grant delete on table public.equipe to authenticated;

-- A partir desta fase nenhuma tabela do aplicativo aceita operações sem uma
-- sessão Auth. As permissões finas por clínica/tabela serão implantadas na Fase 2.
do $$
declare
    objeto record;
begin
    for objeto in
        select tablename
          from pg_tables
         where schemaname = 'public'
    loop
        execute format('revoke all on table public.%I from anon', objeto.tablename);
    end loop;

    for objeto in
        select sequencename
          from pg_sequences
         where schemaname = 'public'
    loop
        execute format('revoke all on sequence public.%I from anon', objeto.sequencename);
    end loop;
end
$$;

create or replace function public.kinesys_perfil_autenticado_tem_papel(
    p_perfil_id text,
    p_papeis text[]
)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
    select exists (
        select 1
          from public.equipe e
         where e.id::text = p_perfil_id
           and e.auth_user_id = auth.uid()
           and upper(btrim(coalesce(e.tipo, ''))) = any(p_papeis)
    );
$$;

revoke all on function public.kinesys_perfil_autenticado_tem_papel(text,text[]) from public, anon;
grant execute on function public.kinesys_perfil_autenticado_tem_papel(text,text[]) to authenticated;

-- Remove a exceção do antigo administrador embutido e vincula a auditoria da
-- Agenda à identidade Auth real, mantendo a assinatura consumida pelo frontend.
create or replace function public.kinesys_listar_historico_status_agenda(
    p_solicitante_id text,
    p_solicitante_tipo text,
    p_solicitante_nome text,
    p_agendamento_id text default null,
    p_limite integer default 100
)
returns table (
    id bigint,
    agendamento_id text,
    agendamento_data date,
    agendamento_hora_inicio time,
    paciente_id text,
    paciente_nome text,
    profissional_responsavel_id text,
    profissional_responsavel_nome text,
    status_anterior text,
    status_novo text,
    observacao_anterior text,
    observacao_nova text,
    alterado_por_id text,
    alterado_por_nome text,
    alterado_por_tipo text,
    alterado_em timestamptz
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    if not public.kinesys_perfil_autenticado_tem_papel(
        p_solicitante_id,
        array['MASTER','MASTER_FEM','ADMINISTRADOR','ADMINISTRADORA']::text[]
    ) then
        raise exception 'KineSys: histórico de status restrito aos administradores autenticados.' using errcode = '42501';
    end if;

    return query
    select h.id, h.agendamento_id, h.agendamento_data, h.agendamento_hora_inicio,
           h.paciente_id, h.paciente_nome, h.profissional_responsavel_id,
           h.profissional_responsavel_nome, h.status_anterior, h.status_novo,
           h.observacao_anterior, h.observacao_nova, h.alterado_por_id,
           h.alterado_por_nome, h.alterado_por_tipo, h.alterado_em
      from public.agendamentos_status_historico h
     where p_agendamento_id is null or h.agendamento_id = p_agendamento_id
     order by h.alterado_em desc, h.id desc
     limit greatest(1, least(coalesce(p_limite, 100), 300));
end;
$$;

revoke all on function public.kinesys_listar_historico_status_agenda(text,text,text,text,integer) from public, anon;
grant execute on function public.kinesys_listar_historico_status_agenda(text,text,text,text,integer) to authenticated;

-- A exportação detalhada também deixa de confiar em id/tipo informados pelo navegador.
create or replace function public.kinesys_listar_auditoria_clinica_prontuario(
    p_solicitante_id text,
    p_solicitante_tipo text,
    p_solicitante_nome text,
    p_paciente_id text,
    p_limite integer default 500
)
returns table (
    id bigint,
    tabela text,
    registro_id text,
    paciente_id text,
    alterado_em timestamptz,
    alterado_por_id text,
    alterado_por_nome text,
    antes jsonb,
    depois jsonb
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    if btrim(coalesce(p_paciente_id, '')) = '' then
        raise exception 'KineSys: paciente não informado.' using errcode = '22023';
    end if;

    if not public.kinesys_perfil_autenticado_tem_papel(
        p_solicitante_id,
        array['MASTER','MASTER_FEM','ADMINISTRADOR','ADMINISTRADORA','FISIOTERAPEUTA','PROFISSIONAL']::text[]
    ) then
        raise exception 'KineSys: usuário autenticado não autorizado a consultar a trilha clínica.' using errcode = '42501';
    end if;

    return query
    select a.id, a.tabela, a.registro_id, a.paciente_id, a.alterado_em,
           a.alterado_por_id, a.alterado_por_nome, a.antes, a.depois
      from public.auditoria_registros_clinicos a
     where a.paciente_id = p_paciente_id
     order by a.alterado_em asc, a.id asc
     limit greatest(1, least(coalesce(p_limite, 500), 1000));
end;
$$;

revoke all on function public.kinesys_listar_auditoria_clinica_prontuario(text,text,text,text,integer) from public, anon;
grant execute on function public.kinesys_listar_auditoria_clinica_prontuario(text,text,text,text,integer) to authenticated;

-- Encapsula a exclusão legada: a implementação transacional original permanece,
-- mas somente um administrador Auth pode chamá-la pela API.
do $$
begin
    if to_regprocedure('public.kinesys_excluir_paciente_completo_interno_v1112(text)') is null
       and to_regprocedure('public.kinesys_excluir_paciente_completo(text)') is not null then
        alter function public.kinesys_excluir_paciente_completo(text)
            rename to kinesys_excluir_paciente_completo_interno_v1112;
    end if;
end
$$;

revoke all on function public.kinesys_excluir_paciente_completo_interno_v1112(text) from public, anon, authenticated;

create or replace function public.kinesys_excluir_paciente_completo(p_paciente_id text)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    if not public.kinesys_is_admin() then
        raise exception 'KineSys: exclusão completa restrita aos administradores autenticados.' using errcode = '42501';
    end if;
    return public.kinesys_excluir_paciente_completo_interno_v1112(p_paciente_id);
end;
$$;

revoke all on function public.kinesys_excluir_paciente_completo(text) from public, anon;
grant execute on function public.kinesys_excluir_paciente_completo(text) to authenticated;

-- RPCs restantes usadas pelo aplicativo passam a exigir sessão Auth. A Fase 2
-- aplicará as políticas específicas por operação e clínica.
revoke all on function public.kinesys_listar_mensagens_padrao() from public, anon;
grant execute on function public.kinesys_listar_mensagens_padrao() to authenticated;

create or replace function public.kinesys_salvar_mensagem_padrao(
    p_chave text,
    p_titulo text,
    p_mensagem text,
    p_atualizado_por_id text default null,
    p_atualizado_por_nome text default null
)
returns table (
    chave text,
    titulo text,
    grupo text,
    descricao text,
    mensagem text,
    ordem integer,
    atualizado_em timestamptz,
    atualizado_por_id text,
    atualizado_por_nome text
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    if not public.kinesys_perfil_autenticado_tem_papel(
        p_atualizado_por_id,
        array['MASTER','MASTER_FEM','ADMINISTRADOR','ADMINISTRADORA']::text[]
    ) then
        raise exception 'KineSys: mensagens padrão só podem ser alteradas por administradores autenticados.' using errcode = '42501';
    end if;
    if p_chave is null or not exists (select 1 from public.configuracoes_mensagens c where c.chave = p_chave) then
        raise exception 'KineSys: modelo de mensagem não reconhecido.' using errcode = '22023';
    end if;
    if length(btrim(coalesce(p_mensagem, ''))) < 8 then
        raise exception 'KineSys: a mensagem está vazia ou muito curta.' using errcode = '22023';
    end if;

    update public.configuracoes_mensagens c
       set titulo = coalesce(nullif(btrim(p_titulo), ''), c.titulo),
           mensagem = btrim(p_mensagem),
           atualizado_em = clock_timestamp(),
           atualizado_por_id = p_atualizado_por_id,
           atualizado_por_nome = coalesce(nullif(btrim(p_atualizado_por_nome), ''), 'Administrador')
     where c.chave = p_chave;

    return query
    select c.chave, c.titulo, c.grupo, c.descricao, c.mensagem, c.ordem,
           c.atualizado_em, c.atualizado_por_id, c.atualizado_por_nome
      from public.configuracoes_mensagens c
     where c.chave = p_chave;
end;
$$;

revoke all on function public.kinesys_salvar_mensagem_padrao(text,text,text,text,text) from public, anon;
grant execute on function public.kinesys_salvar_mensagem_padrao(text,text,text,text,text) to authenticated;

commit;

notify pgrst, 'reload schema';

-- VERIFICAÇÃO FINAL
-- senha_existe deve permanecer TRUE nesta variante de compatibilidade.
-- perfis_sem_auth indica cadastros preservados que ainda não podem entrar na v1.12.0.
select
    exists (
        select 1 from information_schema.columns
         where table_schema = 'public'
           and table_name = 'equipe'
           and column_name = 'senha'
    ) as senha_existe,
    count(*) filter (where auth_user_id is null) as perfis_sem_auth,
    count(*) as perfis_totais
from public.equipe;
