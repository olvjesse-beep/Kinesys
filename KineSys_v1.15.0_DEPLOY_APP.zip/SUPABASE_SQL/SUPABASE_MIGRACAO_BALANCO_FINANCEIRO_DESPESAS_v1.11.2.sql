-- KineSys v1.11.2 — Balanço financeiro mensal / despesas administrativas
-- Migração NÃO DESTRUTIVA. Cria apenas a tabela de despesas usada pelo painel administrativo.

begin;

create table if not exists public.despesas_financeiras (
    id uuid primary key default gen_random_uuid(),
    descricao text not null,
    categoria text not null default 'Outros',
    subcategoria text,
    valor numeric(12,2) not null check (valor > 0),
    data_despesa date not null default current_date,
    forma_pagamento text,
    observacoes text,
    criado_por text,
    criado_em timestamptz not null default now(),
    operacao_id text
);

create unique index if not exists despesas_financeiras_operacao_uidx
    on public.despesas_financeiras (operacao_id) where operacao_id is not null;
create index if not exists despesas_financeiras_data_idx
    on public.despesas_financeiras (data_despesa desc);
create index if not exists despesas_financeiras_categoria_idx
    on public.despesas_financeiras (categoria, data_despesa desc);
create index if not exists despesas_financeiras_subcategoria_idx
    on public.despesas_financeiras (subcategoria, data_despesa desc);

comment on table public.despesas_financeiras is
'Gastos administrativos usados no balanço mensal do KineSys. A interface restringe esta visão aos administradores.';

-- O KineSys atual ainda usa autenticação legada no frontend; por isso a tabela
-- permanece compatível com a chave publicável do projeto. A autorização forte
-- por perfil deverá ser feita quando o sistema migrar para Supabase Auth + RLS.
grant select, insert, update, delete on public.despesas_financeiras to anon, authenticated;

commit;
notify pgrst, 'reload schema';

select table_name, column_name, data_type
from information_schema.columns
where table_schema='public' and table_name='despesas_financeiras'
order by ordinal_position;
