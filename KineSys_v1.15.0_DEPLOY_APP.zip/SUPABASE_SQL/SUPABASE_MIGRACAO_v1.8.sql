-- KineSys Clinical v1.8.0
-- Execute UMA VEZ no Supabase > SQL Editor antes de usar as novas funções de equipe/evolução.
-- Faça backup do projeto antes de migrations em produção.

begin;

-- 1) Evoluções: preserva todo o bloco clínico estruturado entre computadores/sessões.
alter table public.evolucoes
    add column if not exists data_hora_iso timestamptz,
    add column if not exists relato_livre text,
    add column if not exists dados_estruturados jsonb not null default '{}'::jsonb,
    add column if not exists profissional_id text;

-- Backfill seguro para registros antigos.
update public.evolucoes
set data_hora_iso = coalesce(data_hora_iso, now())
where data_hora_iso is null;

-- 2) Equipe: separa conselho/regional/número e perfil profissional.
alter table public.equipe
    add column if not exists conselho text,
    add column if not exists regional text,
    add column if not exists numero_registro text;

-- 3) Índices de unicidade para impedir duplicidade também no banco.
-- Se um índice falhar, já existem duplicados: revise-os antes e execute de novo.
create unique index if not exists equipe_email_unique_ci
    on public.equipe (lower(btrim(email)));

create unique index if not exists equipe_cpf_unique
    on public.equipe ((regexp_replace(cpf, '[^0-9]', '', 'g')))
    where cpf is not null and regexp_replace(cpf, '[^0-9]', '', 'g') <> '';

create unique index if not exists equipe_registro_unique_ci
    on public.equipe ((regexp_replace(lower(registro), '\s+', '', 'g')))
    where registro is not null and btrim(registro) <> '' and lower(registro) <> 'secretaria';

commit;

-- Verificação opcional após executar:
-- select column_name, data_type from information_schema.columns
-- where table_schema='public' and table_name in ('evolucoes','equipe')
-- order by table_name, ordinal_position;
