-- KineSys Clinical v1.11.2
-- ITEM 9 — Rastreabilidade de Avaliações e Evoluções + janela de edição de 24 h
-- REVISÃO 2 — compatível com data_hora_iso TEXT ou TIMESTAMPTZ
-- Execute UMA VEZ no Supabase > SQL Editor.
-- Não apaga registros clínicos existentes.

begin;

-- ---------------------------------------------------------------------------
-- 0) Conversão compatível de datas legadas
-- Em algumas instalações antigas, data_hora_iso existe como TEXT; em outras,
-- como TIMESTAMPTZ. Esta função recebe sempre texto e converte com segurança.
-- Valores vazios ou legados inválidos retornam NULL em vez de abortar a migration.
-- ---------------------------------------------------------------------------
create or replace function public.kinesys_try_timestamptz(p_value text)
returns timestamptz
language plpgsql
stable
as $$
begin
    if p_value is null or btrim(p_value) = '' then
        return null;
    end if;
    begin
        return p_value::timestamptz;
    exception when others then
        return null;
    end;
end;
$$;

-- ---------------------------------------------------------------------------
-- 1) Metadados de rastreabilidade
-- ---------------------------------------------------------------------------
alter table public.avaliacoes
    add column if not exists realizado_em timestamptz,
    add column if not exists salvo_em timestamptz,
    add column if not exists edicao_limite_em timestamptz,
    add column if not exists profissional_id text,
    add column if not exists profissional_nome text,
    add column if not exists profissional_registro text,
    add column if not exists ultima_edicao_em timestamptz,
    add column if not exists ultima_edicao_por_id text,
    add column if not exists ultima_edicao_por_nome text;

alter table public.evolucoes
    add column if not exists realizado_em timestamptz,
    add column if not exists salvo_em timestamptz,
    add column if not exists edicao_limite_em timestamptz,
    add column if not exists profissional_nome text,
    add column if not exists profissional_registro text,
    add column if not exists ultima_edicao_em timestamptz,
    add column if not exists ultima_edicao_por_id text,
    add column if not exists ultima_edicao_por_nome text;

-- profissional_id já existe em evolucoes desde a migration v1.8; garante
-- compatibilidade caso a instalação tenha pulado aquela versão.
alter table public.evolucoes
    add column if not exists profissional_id text;

-- ---------------------------------------------------------------------------
-- 2) Backfill de registros antigos
-- Registros legados não possuíam um campo separado para "realizado em" e
-- "salvo em". Neles usamos o melhor carimbo já existente (data_hora_iso).
-- Isso NÃO inventa um horário novo nem reescreve o histórico clínico.
-- ---------------------------------------------------------------------------
update public.avaliacoes
set
    realizado_em = coalesce(realizado_em, public.kinesys_try_timestamptz(data_hora_iso::text), now()),
    salvo_em = coalesce(salvo_em, public.kinesys_try_timestamptz(data_hora_iso::text), now()),
    profissional_nome = coalesce(nullif(btrim(profissional_nome), ''), nullif(btrim(realizado_por), ''), 'Registro legado'),
    edicao_limite_em = coalesce(edicao_limite_em, coalesce(realizado_em, public.kinesys_try_timestamptz(data_hora_iso::text), now()) + interval '24 hours')
where realizado_em is null
   or salvo_em is null
   or edicao_limite_em is null
   or profissional_nome is null
   or btrim(profissional_nome) = '';

update public.evolucoes
set
    realizado_em = coalesce(realizado_em, public.kinesys_try_timestamptz(data_hora_iso::text), now()),
    salvo_em = coalesce(salvo_em, public.kinesys_try_timestamptz(data_hora_iso::text), now()),
    profissional_nome = coalesce(nullif(btrim(profissional_nome), ''), nullif(btrim(profissional), ''), 'Registro legado'),
    edicao_limite_em = coalesce(edicao_limite_em, coalesce(realizado_em, public.kinesys_try_timestamptz(data_hora_iso::text), now()) + interval '24 hours')
where realizado_em is null
   or salvo_em is null
   or edicao_limite_em is null
   or profissional_nome is null
   or btrim(profissional_nome) = '';

alter table public.avaliacoes alter column salvo_em set default now();
alter table public.evolucoes alter column salvo_em set default now();

alter table public.avaliacoes alter column realizado_em set not null;
alter table public.avaliacoes alter column salvo_em set not null;
alter table public.avaliacoes alter column edicao_limite_em set not null;
alter table public.evolucoes alter column realizado_em set not null;
alter table public.evolucoes alter column salvo_em set not null;
alter table public.evolucoes alter column edicao_limite_em set not null;

comment on column public.avaliacoes.realizado_em is 'Data/hora em que o atendimento/avaliação foi realizado. Base da janela fixa de edição.';
comment on column public.avaliacoes.salvo_em is 'Primeiro carimbo de salvamento no banco. Imutável após a criação.';
comment on column public.avaliacoes.edicao_limite_em is 'Limite imutável de edição: realizado_em original + 24 horas.';
comment on column public.evolucoes.realizado_em is 'Data/hora em que o atendimento foi realizado. Base da janela fixa de edição.';
comment on column public.evolucoes.salvo_em is 'Primeiro carimbo de salvamento no banco. Imutável após a criação.';
comment on column public.evolucoes.edicao_limite_em is 'Limite imutável de edição: realizado_em original + 24 horas.';

-- ---------------------------------------------------------------------------
-- 3) Auditoria interna de alterações clínicas
-- Não é usada para editar o prontuário; serve apenas como trilha técnica.
-- ---------------------------------------------------------------------------
create table if not exists public.auditoria_registros_clinicos (
    id bigserial primary key,
    tabela text not null check (tabela in ('avaliacoes','evolucoes')),
    registro_id text not null,
    paciente_id text,
    alterado_em timestamptz not null default now(),
    alterado_por_id text,
    alterado_por_nome text,
    antes jsonb not null,
    depois jsonb not null
);

create index if not exists auditoria_registros_clinicos_registro_idx
    on public.auditoria_registros_clinicos (tabela, registro_id, alterado_em desc);
create index if not exists auditoria_registros_clinicos_paciente_idx
    on public.auditoria_registros_clinicos (paciente_id, alterado_em desc);

comment on table public.auditoria_registros_clinicos is
'Trilha técnica das alterações efetivas em avaliações/evoluções durante a janela permitida. Não substitui o prontuário.';

-- O aplicativo não precisa ler/escrever esta tabela diretamente.
revoke all on table public.auditoria_registros_clinicos from anon, authenticated;
revoke all on sequence public.auditoria_registros_clinicos_id_seq from anon, authenticated;

-- ---------------------------------------------------------------------------
-- 4) Proteção no próprio PostgreSQL
-- A interface esconde o botão após 24 h, mas esta trigger é a barreira real:
-- mesmo uma chamada direta à API não consegue modificar conteúdo clínico
-- depois do prazo. Upserts idênticos são aceitos para não quebrar a sincronização.
-- ---------------------------------------------------------------------------
create or replace function public.kinesys_proteger_registro_clinico_24h()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
    v_agora timestamptz := clock_timestamp();
    v_ator_id text;
    v_ator_nome text;
    v_antes jsonb;
    v_depois jsonb;
    v_comparar_antes jsonb;
    v_comparar_depois jsonb;
    v_nome_fallback text;
begin
    if tg_op = 'INSERT' then
        -- O carimbo de salvamento é sempre o relógio do banco, não o navegador.
        new.salvo_em := v_agora;
        new.realizado_em := coalesce(
            new.realizado_em,
            public.kinesys_try_timestamptz(to_jsonb(new)->>'data_hora_iso'),
            v_agora
        );

        if new.realizado_em > v_agora + interval '5 minutes' then
            raise exception using
                errcode = '22007',
                message = 'KineSys: a data/hora de realização não pode estar no futuro.';
        end if;

        new.edicao_limite_em := new.realizado_em + interval '24 hours';
        new.ultima_edicao_em := null;
        new.ultima_edicao_por_id := null;
        new.ultima_edicao_por_nome := null;

        v_nome_fallback := coalesce(
            nullif(btrim(to_jsonb(new)->>'realizado_por'), ''),
            nullif(btrim(to_jsonb(new)->>'profissional'), ''),
            'Profissional não identificado'
        );
        new.profissional_nome := coalesce(nullif(btrim(new.profissional_nome), ''), v_nome_fallback);
        return new;
    end if;

    -- Guarda quem solicitou a correção antes de restaurar campos imutáveis.
    v_ator_id := new.ultima_edicao_por_id;
    v_ator_nome := new.ultima_edicao_por_nome;

    -- Estes carimbos/identidade pertencem ao registro original e nunca são
    -- reescritos por uma edição posterior.
    new.salvo_em := old.salvo_em;
    new.edicao_limite_em := old.edicao_limite_em;
    new.profissional_id := old.profissional_id;
    new.profissional_nome := old.profissional_nome;
    new.profissional_registro := old.profissional_registro;

    v_antes := to_jsonb(old);
    v_depois := to_jsonb(new);

    -- Ignora somente campos da própria auditoria na comparação. Assim um
    -- upsert sem mudança clínica permanece permitido mesmo após 24 h.
    v_comparar_antes := v_antes - array[
        'ultima_edicao_em','ultima_edicao_por_id','ultima_edicao_por_nome'
    ];
    v_comparar_depois := v_depois - array[
        'ultima_edicao_em','ultima_edicao_por_id','ultima_edicao_por_nome'
    ];

    if v_comparar_antes is distinct from v_comparar_depois then
        if v_agora > old.edicao_limite_em then
            raise exception using
                errcode = '55000',
                message = format(
                    'KineSys: edição bloqueada. O prazo de 24 horas deste registro terminou em %s.',
                    to_char(old.edicao_limite_em at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI:SS')
                );
        end if;

        if new.realizado_em > v_agora + interval '5 minutes' then
            raise exception using
                errcode = '22007',
                message = 'KineSys: a data/hora de realização não pode estar no futuro.';
        end if;

        new.ultima_edicao_em := v_agora;
        new.ultima_edicao_por_id := v_ator_id;
        new.ultima_edicao_por_nome := coalesce(nullif(btrim(v_ator_nome), ''), 'Usuário não identificado');

        insert into public.auditoria_registros_clinicos
            (tabela, registro_id, paciente_id, alterado_em, alterado_por_id, alterado_por_nome, antes, depois)
        values
            (tg_table_name, old.id::text, old.paciente_id::text, v_agora, v_ator_id,
             new.ultima_edicao_por_nome, v_antes, to_jsonb(new));
    else
        -- Sem mudança real: preserva o último evento de auditoria.
        new.ultima_edicao_em := old.ultima_edicao_em;
        new.ultima_edicao_por_id := old.ultima_edicao_por_id;
        new.ultima_edicao_por_nome := old.ultima_edicao_por_nome;
    end if;

    return new;
end;
$$;

drop trigger if exists trg_kinesys_avaliacoes_24h on public.avaliacoes;
create trigger trg_kinesys_avaliacoes_24h
before insert or update on public.avaliacoes
for each row execute function public.kinesys_proteger_registro_clinico_24h();

drop trigger if exists trg_kinesys_evolucoes_24h on public.evolucoes;
create trigger trg_kinesys_evolucoes_24h
before insert or update on public.evolucoes
for each row execute function public.kinesys_proteger_registro_clinico_24h();

commit;

-- ---------------------------------------------------------------------------
-- A função public.kinesys_try_timestamptz permanece instalada porque a trigger
-- a utiliza para manter compatibilidade com bancos legados em que data_hora_iso é TEXT.

-- VERIFICAÇÃO OPCIONAL
-- ---------------------------------------------------------------------------
-- select column_name, data_type
-- from information_schema.columns
-- where table_schema='public'
--   and table_name in ('avaliacoes','evolucoes')
--   and column_name in ('realizado_em','salvo_em','edicao_limite_em','profissional_nome','profissional_registro','ultima_edicao_em')
-- order by table_name, column_name;
