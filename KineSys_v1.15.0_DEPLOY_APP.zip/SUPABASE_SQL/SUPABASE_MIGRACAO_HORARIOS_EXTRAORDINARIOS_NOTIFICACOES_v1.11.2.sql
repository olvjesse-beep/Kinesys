-- KineSys Clinical v1.11.2 — Horários extraordinários + avisos internos da Agenda
-- Migration NÃO destrutiva. Não remove nem reclassifica dados existentes.

begin;

alter table public.agendamentos
    add column if not exists horario_extraordinario boolean not null default false,
    add column if not exists horario_extraordinario_confirmado_por text,
    add column if not exists horario_extraordinario_confirmado_em timestamptz;

create index if not exists agendamentos_horario_extraordinario_idx
    on public.agendamentos (profissional_id, data, horario_extraordinario)
    where horario_extraordinario = true;

create table if not exists public.notificacoes_internas (
    id uuid primary key default gen_random_uuid(),
    destinatario_profissional_id text not null references public.equipe(id) on delete cascade,
    destinatario_email text,
    tipo text not null default 'agenda',
    titulo text not null,
    mensagem text not null,
    agendamento_id text,
    agendamento_data date,
    origem_chave text not null unique,
    criada_por text,
    criada_em timestamptz not null default now(),
    lida boolean not null default false,
    lida_em timestamptz
);

create index if not exists notificacoes_internas_destinatario_idx
    on public.notificacoes_internas (destinatario_profissional_id, lida, criada_em desc);
create index if not exists notificacoes_internas_email_idx
    on public.notificacoes_internas (lower(destinatario_email), lida, criada_em desc)
    where destinatario_email is not null;

comment on column public.agendamentos.horario_extraordinario is
    'True quando o agendamento foi confirmado fora da jornada padrão da clínica/profissional.';
comment on table public.notificacoes_internas is
    'Avisos operacionais internos do KineSys, incluindo agendamentos fora da jornada padrão.';

-- O KineSys atual usa a chave publicável do projeto para operar as tabelas.
-- Estas permissões ficam restritas a esta nova tabela de avisos; nenhuma função destrutiva é criada.
grant select, insert, update on public.notificacoes_internas to anon, authenticated;

commit;
notify pgrst, 'reload schema';

-- Verificação: deve retornar os campos e a tabela abaixo.
select table_name, column_name, data_type
from information_schema.columns
where table_schema='public'
  and (
    (table_name='agendamentos' and column_name in ('horario_extraordinario','horario_extraordinario_confirmado_por','horario_extraordinario_confirmado_em'))
    or table_name='notificacoes_internas'
  )
order by table_name, ordinal_position;
