-- KineSys Clinical v1.11.2 — CORREÇÃO CRÍTICA DA AGENDA
-- Corrige o erro:
--   new row for relation "agendamentos" violates check constraint "agendamentos_status_check"
--
-- Pode ser executado com segurança mais de uma vez no SQL Editor do Supabase.
-- Preserva registros antigos e libera todos os status usados pela Agenda atual.

begin;

-- O JavaScript atual cria novos registros como 'agendado' por padrão.
alter table public.agendamentos
    alter column status set default 'agendado';

-- A constraint antiga ficou incompatível com os status da Agenda v1.11.2.
alter table public.agendamentos
    drop constraint if exists agendamentos_status_check;

alter table public.agendamentos
    add constraint agendamentos_status_check
    check (status in ('pre_agendado','agendado','confirmado','em_recepcao','atendido','falta_justificada','falta_nao_justificada','cancelado','concluido','faltou'))
    not valid;

-- Valida todo o histórico somente se não houver status antigo/desconhecido.
-- Se houver, a constraint continua protegendo INSERTs/UPDATEs novos sem apagar histórico.
do $$
begin
    if not exists (
        select 1
        from public.agendamentos
        where status is not null
          and status not in ('pre_agendado','agendado','confirmado','em_recepcao','atendido','falta_justificada','falta_nao_justificada','cancelado','concluido','faltou')
    ) then
        alter table public.agendamentos
            validate constraint agendamentos_status_check;
    end if;
end $$;

commit;
notify pgrst, 'reload schema';

-- Diagnóstico final: deve listar a constraint acima e os status encontrados no banco.
select conname as constraint_name,
       pg_get_constraintdef(oid) as definition,
       convalidated as validada
from pg_constraint
where conrelid = 'public.agendamentos'::regclass
  and conname = 'agendamentos_status_check';

select status, count(*) as quantidade
from public.agendamentos
group by status
order by status;
