-- KineSys Clinical v1.10.4 — Planos de atendimento e pagamentos
-- Execute UMA VEZ no Supabase > SQL Editor.
-- Esta migration COMPLEMENTA a Agenda existente; não recria procedimentos/agendamentos.
-- Pré-requisitos: public.pacientes(id text) e public.procedimentos(id uuid) já existentes.

begin;

create table if not exists public.planos_atendimento (
    id uuid primary key default gen_random_uuid(),
    paciente_id text not null references public.pacientes(id) on delete cascade,
    procedimento_id uuid references public.procedimentos(id) on delete set null,
    nome text not null,
    sessoes_contratadas integer not null check (sessoes_contratadas > 0),
    valor_tabela numeric(12,2) not null default 0 check (valor_tabela >= 0),
    desconto_valor numeric(12,2) not null default 0 check (desconto_valor >= 0),
    valor_final numeric(12,2) not null default 0 check (valor_final >= 0),
    forma_pagamento_prevista text,
    parcelas integer not null default 1 check (parcelas > 0),
    observacoes text,
    status text not null default 'ativo' check (status in ('ativo','concluido','cancelado')),
    criado_por text,
    criado_em timestamptz not null default now(),
    encerrado_em timestamptz,
    operacao_id text
);

create unique index if not exists planos_atendimento_operacao_uidx
    on public.planos_atendimento (operacao_id)
    where operacao_id is not null;
create index if not exists planos_atendimento_paciente_idx
    on public.planos_atendimento (paciente_id, status);

create table if not exists public.pagamentos (
    id uuid primary key default gen_random_uuid(),
    plano_id uuid not null references public.planos_atendimento(id) on delete restrict,
    paciente_id text not null references public.pacientes(id) on delete cascade,
    valor numeric(12,2) not null check (valor > 0),
    forma_pagamento text not null,
    data_pagamento date not null default current_date,
    observacoes text,
    criado_por text,
    criado_em timestamptz not null default now(),
    operacao_id text
);

create unique index if not exists pagamentos_operacao_uidx
    on public.pagamentos (operacao_id)
    where operacao_id is not null;
create index if not exists pagamentos_paciente_idx
    on public.pagamentos (paciente_id, data_pagamento desc);
create index if not exists pagamentos_plano_idx
    on public.pagamentos (plano_id, data_pagamento desc);

alter table public.agendamentos
    add column if not exists plano_id uuid;

do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname = 'agendamentos_plano_id_fkey'
          and conrelid = 'public.agendamentos'::regclass
    ) then
        alter table public.agendamentos
            add constraint agendamentos_plano_id_fkey
            foreign key (plano_id) references public.planos_atendimento(id) on delete set null;
    end if;
end $$;

create index if not exists agendamentos_plano_idx
    on public.agendamentos (plano_id, status)
    where plano_id is not null;

commit;

-- IMPORTANTE SOBRE RLS
-- O KineSys atual ainda utiliza o login legado no frontend e não usa Supabase Auth.
-- NÃO habilite RLS nessas tabelas isoladamente neste momento: isso pode impedir o
-- painel administrativo de ler/escrever. A proteção definitiva deve ser feita junto
-- da futura migração de autenticação para Supabase Auth + policies por perfil.
--
-- A contagem de sessões funciona assim:
--   sessões realizadas = agendamentos vinculados ao plano com status='concluido'
--   sessões restantes  = sessoes_contratadas - sessões realizadas
-- Faltas/cancelamentos não consomem sessão automaticamente.
