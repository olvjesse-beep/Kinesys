-- KineSys v1.11.2 — separação da origem dos descontos
-- Migração NÃO DESTRUTIVA. Não apaga nem reclassifica descontos históricos.

begin;

alter table public.planos_atendimento
    add column if not exists desconto_pacote numeric(12,2) not null default 0,
    add column if not exists desconto_cortesia numeric(12,2) not null default 0;

-- Garante valores válidos sem alterar o campo legado desconto_valor.
update public.planos_atendimento set desconto_pacote = 0 where desconto_pacote is null;
update public.planos_atendimento set desconto_cortesia = 0 where desconto_cortesia is null;

-- Constraints são adicionadas somente se ainda não existirem.
do $$
begin
    if not exists (
        select 1 from pg_constraint
        where conname = 'planos_atendimento_desconto_pacote_ck'
          and conrelid = 'public.planos_atendimento'::regclass
    ) then
        alter table public.planos_atendimento
            add constraint planos_atendimento_desconto_pacote_ck check (desconto_pacote >= 0);
    end if;

    if not exists (
        select 1 from pg_constraint
        where conname = 'planos_atendimento_desconto_cortesia_ck'
          and conrelid = 'public.planos_atendimento'::regclass
    ) then
        alter table public.planos_atendimento
            add constraint planos_atendimento_desconto_cortesia_ck check (desconto_cortesia >= 0);
    end if;
end $$;

comment on column public.planos_atendimento.desconto_pacote is
'Desconto concedido por adesão a pacote/plano. desconto_valor permanece como total para compatibilidade.';
comment on column public.planos_atendimento.desconto_cortesia is
'Desconto excepcional concedido ao paciente por decisão da clínica. desconto_valor permanece como total para compatibilidade.';

commit;
