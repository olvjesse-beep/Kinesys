-- KineSys Clinical v1.11.2 — exclusão segura de paciente
-- Objetivo: excluir cadastro + histórico relacionado em UMA transação.
-- Pode ser executado novamente; CREATE OR REPLACE é idempotente.
--
-- IMPORTANTE: o KineSys atual ainda usa autenticação própria no navegador.
-- Esta função segue a arquitetura atual do projeto. Na futura migração para
-- Supabase Auth, restrinja EXECUTE por RLS/perfil administrativo.

begin;

create or replace function public.kinesys_excluir_paciente_completo(p_paciente_id text)
returns jsonb
language plpgsql
security invoker
set search_path = public, pg_temp
as $$
declare
    v_nome text;
    v_total bigint := 0;
    v_rows bigint := 0;
    r record;
begin
    if p_paciente_id is null or btrim(p_paciente_id) = '' then
        raise exception 'KineSys: paciente_id é obrigatório.';
    end if;

    select nome into v_nome
    from public.pacientes
    where id::text = p_paciente_id
    for update;

    if not found then
        raise exception 'KineSys: paciente não encontrado (%).', p_paciente_id;
    end if;

    -- Ordem explícita para as tabelas conhecidas do KineSys.
    if to_regclass('public.pagamentos') is not null then
        delete from public.pagamentos where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    if to_regclass('public.agendamentos') is not null then
        delete from public.agendamentos where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    if to_regclass('public.lista_espera') is not null then
        delete from public.lista_espera where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    if to_regclass('public.arquivos_paciente') is not null then
        delete from public.arquivos_paciente where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    if to_regclass('public.evolucoes') is not null then
        delete from public.evolucoes where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    if to_regclass('public.avaliacoes') is not null then
        delete from public.avaliacoes where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    if to_regclass('public.planos_atendimento') is not null then
        delete from public.planos_atendimento where paciente_id::text = p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end if;

    -- Proteção futura: se novos módulos criarem uma tabela BASE com coluna
    -- paciente_id, ela também é limpa antes do cadastro principal.
    for r in
        select c.table_name
        from information_schema.columns c
        join information_schema.tables t
          on t.table_schema = c.table_schema
         and t.table_name = c.table_name
        where c.table_schema = 'public'
          and c.column_name = 'paciente_id'
          and t.table_type = 'BASE TABLE'
          and c.table_name not in (
              'pagamentos','agendamentos','lista_espera','arquivos_paciente',
              'evolucoes','avaliacoes','planos_atendimento','pacientes'
          )
    loop
        execute format('delete from public.%I where paciente_id::text = $1', r.table_name)
        using p_paciente_id;
        get diagnostics v_rows = row_count; v_total := v_total + v_rows;
    end loop;

    delete from public.pacientes where id::text = p_paciente_id;
    if not found then
        raise exception 'KineSys: o cadastro do paciente não pôde ser removido.';
    end if;

    return jsonb_build_object(
        'ok', true,
        'paciente_id', p_paciente_id,
        'paciente_nome', v_nome,
        'registros_historicos_removidos', v_total,
        'cadastro_removido', true
    );
end;
$$;

-- Mantém compatibilidade com a arquitetura atual do KineSys.
grant execute on function public.kinesys_excluir_paciente_completo(text) to anon, authenticated;

commit;

-- Força o PostgREST/Supabase a recarregar a função no schema cache.
notify pgrst, 'reload schema';

-- Verificação: deve retornar uma linha com o nome da função.
select routine_name
from information_schema.routines
where routine_schema='public'
  and routine_name='kinesys_excluir_paciente_completo';
