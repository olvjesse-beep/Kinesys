-- KineSys Clinical v1.11.2 — Status operacionais da Agenda
-- Migration NÃO destrutiva: apenas adiciona metadados de status e um marcador
-- de encerramento automático do pacote. Os status antigos são preservados.

begin;

alter table public.agendamentos
    add column if not exists status_observacao text,
    add column if not exists status_atualizado_em timestamptz,
    add column if not exists status_atualizado_por text,
    add column if not exists chegada_em timestamptz,
    add column if not exists atendido_em timestamptz;

alter table public.planos_atendimento
    add column if not exists encerramento_automatico boolean not null default false;

-- IMPORTANTe: versões anteriores do banco podem ter um CHECK antigo que rejeita
-- os status operacionais atuais e bloqueia TODO novo agendamento.
alter table public.agendamentos
    alter column status set default 'agendado';

alter table public.agendamentos
    drop constraint if exists agendamentos_status_check;

alter table public.agendamentos
    add constraint agendamentos_status_check
    check (status in ('pre_agendado','agendado','confirmado','em_recepcao','atendido','falta_justificada','falta_nao_justificada','cancelado','concluido','faltou'))
    not valid;

do $$
begin
    if not exists (
        select 1 from public.agendamentos
        where status is not null
          and status not in ('pre_agendado','agendado','confirmado','em_recepcao','atendido','falta_justificada','falta_nao_justificada','cancelado','concluido','faltou')
    ) then
        alter table public.agendamentos validate constraint agendamentos_status_check;
    end if;
end $$;

create index if not exists agendamentos_status_operacional_idx
    on public.agendamentos (status, data, profissional_id);

comment on column public.agendamentos.status_observacao is
    'Observação administrativa do status (falta justificada, falta não justificada ou cancelamento).';
comment on column public.agendamentos.chegada_em is
    'Momento em que o status foi alterado para em_recepcao.';
comment on column public.agendamentos.atendido_em is
    'Momento em que o status foi alterado para atendido.';
comment on column public.planos_atendimento.encerramento_automatico is
    'True somente quando o KineSys concluiu o pacote automaticamente por consumo de todas as sessões.';

commit;
notify pgrst, 'reload schema';

-- Verificação: devem aparecer os 6 campos abaixo.
select table_name, column_name, data_type
from information_schema.columns
where table_schema='public'
  and (
      (table_name='agendamentos' and column_name in ('status_observacao','status_atualizado_em','status_atualizado_por','chegada_em','atendido_em'))
      or
      (table_name='planos_atendimento' and column_name='encerramento_automatico')
  )
order by table_name, column_name;
