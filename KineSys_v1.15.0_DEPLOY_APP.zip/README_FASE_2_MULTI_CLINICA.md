# KineSys v1.14.0 — Fase 2: isolamento por clínica

Esta etapa prepara o KineSys para operar como SaaS multi-clínica. A migration cria a clínica principal **Apta Fisioterapia**, vincula os usuários autenticados já existentes e associa os registros atuais a essa clínica.

## O que a migration faz

- cria `clinicas` e `membros_clinicas`;
- adiciona `clinica_id` às tabelas do produto;
- associa os registros existentes à clínica principal;
- cria vínculo automático entre `equipe.auth_user_id` e a clínica;
- ativa RLS e políticas de leitura, inserção, atualização e exclusão por clínica;
- impede mover um registro de uma clínica para outra por update;
- mantém `public.equipe.senha` sem alteração e não apaga registros.

## Execução

Use o arquivo:

`SUPABASE_SQL/SUPABASE_MIGRACAO_FASE_2_MULTI_CLINICA_v1.14.0.sql`

Antes de executar em produção, faça um backup do banco. A consulta faz uma alteração estrutural e substitui as políticas globais existentes de `equipe`, `documentos_timeline` e `kinesys_migracoes_dados` por políticas restritas à clínica.

Ao final, a verificação deve retornar:

- `clinica_principal = 1`;
- `membros_vinculados` igual ao número de usuários autenticados vinculados à equipe;
- `rls_pacientes = 1`.

## Próximos passos

Depois de aplicar a migration, validar com dois usuários de clínicas diferentes que cada um enxerga somente seus próprios registros. Só então habilitar criação de novas clínicas, seleção de tenant, cobrança por clínica e convites de equipe.

Esta etapa é técnica; não constitui certificação jurídica de conformidade LGPD.
