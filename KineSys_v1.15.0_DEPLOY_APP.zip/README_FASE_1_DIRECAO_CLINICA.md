# KineSys v1.15.0 — Fase 1: direção clínica assistida

Esta etapa ajusta a linguagem e a saída do motor clínico para que ele funcione como apoio à decisão fisioterapêutica, sem apresentar uma condição como diagnóstico confirmado.

## Alterações

- substituição dos rótulos visíveis de hipótese por eixo, direção, pista e investigação em aberto;
- nova hierarquia visual Clinical Focus: segurança → eixo → próximo exame → decisão profissional;
- revisão de segurança global movida para uma ação compacta ao final da etapa 2, com detalhe expansível sob demanda;
- entrada na etapa 2 reposicionada no topo do exame, preservando a rolagem livre do conteúdo;
- painel do motor redesenhado com mensagem de objetivo, rotas de exame mais claras e biblioteca específica opcional;
- blocos de segurança regional sem alerta ativo ocultados para reduzir repetição visual;
- respostas dos testes exibidas como compatível / não compatível / inconclusivo, preservando os valores armazenados;
- síntese com linguagem de achados compatíveis, sem confirmação diagnóstica automática;
- aviso persistente na síntese explicando o papel do KineSys;
- registro adicional de `direcaoInvestigacao`, `codigoEixo`, `nomeEixo` e `eixosAssociados`;
- campos legados (`hipotese`, `codigoHipotese` e equivalentes) preservados para compatibilidade;
- documentação automática com ressalva explícita de que a informação não estabelece diagnóstico;
- estados inconclusivos e investigação em aberto mantidos como desfechos válidos;
- versão do motor atualizada para 2.4.0 e do aplicativo para 1.15.0.

## Limites desta fase

As regras heurísticas e o banco clínico ainda não foram validados como instrumento diagnóstico. A Fase 1 corrige o contrato semântico e a apresentação. A separação estrutural entre fatos, evidências, incerteza e decisão profissional será feita na Fase 2.

## Validação prevista

1. verificar a sintaxe dos JavaScript;
2. testar uma avaliação com eixo compatível;
3. testar resultado negativo e inconclusivo;
4. verificar que a síntese e o texto documental não usam confirmação diagnóstica automática;
5. confirmar que dados legados continuam sendo lidos.
