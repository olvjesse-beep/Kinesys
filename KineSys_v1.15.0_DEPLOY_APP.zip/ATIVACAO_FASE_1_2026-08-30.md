# Ativação da Fase 1 — 30/08/2026

## Estado

- Migração `SUPABASE_MIGRACAO_FASE_1_AUTH_v1.12.0.sql` aplicada ao projeto Supabase de produção.
- Conta Supabase Auth do proprietário criada e confirmada.
- Perfil interno `Jesse` vinculado como `MASTER`.
- Dois perfis legados foram preservados sem vínculo Auth e não podem entrar na v1.12.0 até receberem uma conta Supabase Auth.
- A coluna legado `public.equipe.senha` foi preservada por decisão do proprietário.
- A API não possui permissão de leitura ou escrita nessa coluna para os papéis `anon` e `authenticated`.
- RLS está ativa em `public.equipe`.

## Validação executada

- Login real no KineSys com Supabase Auth: aprovado.
- Perfil e permissão exibidos: `Jesse — Administrador`.
- Restauração da sessão após recarregar a página: aprovada.
- Painel e dados existentes carregados: aprovado.
- Identificação visual da versão `v1.12.0`: aprovada.
- Sintaxe JavaScript: 22 de 22 arquivos aprovados.

## Observação

Esta ativação prepara a base segura da Fase 1. A publicação em uma URL definitiva ainda é uma etapa separada.
